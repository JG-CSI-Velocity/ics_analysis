"""Section 2: ICS in Open Accounts"""

import pandas as pd
from ..utils import get_ics_accounts, get_open_accounts

ANALYSIS_ID = "ax02"
ANALYSIS_NAME = "ICS in Open Accounts"
ANALYSIS_SECTION = "summary"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    open_accts = get_open_accounts(data)
    total = len(open_accts)
    ics = len(get_ics_accounts(open_accts))
    non_ics = total - ics
    
    return pd.DataFrame({
        'Category': ['Total Open', 'ICS Open', 'Non-ICS Open'],
        'Count': [total, ics, non_ics],
        '% of Open': [1.0, ics/total if total else 0, non_ics/total if total else 0]
    })
