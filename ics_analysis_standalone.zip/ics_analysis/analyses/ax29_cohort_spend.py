"""Section 29: Cohort Spend Heatmap"""

import pandas as pd
from ..utils import get_ics_stat_o_debit, add_opening_month

ANALYSIS_ID = "ax29"
ANALYSIS_NAME = "Cohort Spend Heatmap"
ANALYSIS_SECTION = "cohort"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    cohort_start = context['cohort_start']
    last_12_months = context['last_12_months']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_opening_month(ics)
    ics = ics[ics['Opening Month'] >= cohort_start].copy()
    
    if len(ics) == 0:
        return pd.DataFrame({'Note': ['No cohort data']})
    
    rows = []
    for cohort in sorted(ics['Opening Month'].unique()):
        cohort_data = ics[ics['Opening Month'] == cohort]
        row = {'Cohort': cohort, 'Size': len(cohort_data)}
        
        for month in last_12_months:
            spend_col = f"{month} Spend"
            if spend_col in cohort_data.columns:
                row[month] = pd.to_numeric(cohort_data[spend_col], errors='coerce').fillna(0).mean()
        
        rows.append(row)
    
    return pd.DataFrame(rows)
