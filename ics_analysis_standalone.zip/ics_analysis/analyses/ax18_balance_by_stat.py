"""Section 18: Balance by Status Code"""

import pandas as pd
from ..utils import get_ics_accounts, add_total_row

ANALYSIS_ID = "ax18"
ANALYSIS_NAME = "Balance by Status Code"
ANALYSIS_SECTION = "demographics"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_accounts(data)
    ics['Stat Code'] = ics['Stat Code'].astype(str).str.upper().str.strip()
    
    result = ics.groupby('Stat Code').agg(
        Count=('Curr Bal', 'count'),
        Total_Balance=('Curr Bal', 'sum'),
        Avg_Balance=('Curr Bal', 'mean')
    ).reset_index()
    
    return result.sort_values('Count', ascending=False).reset_index(drop=True)
