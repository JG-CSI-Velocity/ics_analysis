"""Section 8: ICS Source Distribution"""

import pandas as pd
from ..utils import get_ics_accounts, add_total_row, normalize_column

ANALYSIS_ID = "ax08"
ANALYSIS_NAME = "ICS Source Distribution"
ANALYSIS_SECTION = "source"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_accounts(data)
    ics = normalize_column(ics, 'Source')
    
    dist = ics['Source'].value_counts().reset_index()
    dist.columns = ['Source', 'Count']
    dist['% of ICS'] = dist['Count'] / len(ics)
    
    dist = dist.sort_values('Count', ascending=False).reset_index(drop=True)
    return add_total_row(dist, 'Source', pct_cols=['% of ICS'])
