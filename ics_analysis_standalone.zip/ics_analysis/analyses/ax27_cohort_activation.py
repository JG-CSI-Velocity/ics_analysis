"""Section 27: Cohort Activation Analysis"""

import pandas as pd
from dateutil.relativedelta import relativedelta
from ..utils import get_ics_stat_o_debit, add_opening_month

ANALYSIS_ID = "ax27"
ANALYSIS_NAME = "Cohort Activation Analysis"
ANALYSIS_SECTION = "cohort"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    cohort_start = context['cohort_start']
    last_12_months = context['last_12_months']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_opening_month(ics)
    ics = ics[ics['Opening Month'] >= cohort_start].copy()
    
    if len(ics) == 0:
        return pd.DataFrame({'Note': [f'No accounts opened since {cohort_start}']})
    
    months = sorted(ics['Opening Month'].unique())
    milestones = {'M1': 0, 'M3': 2, 'M6': 5, 'M12': 11}
    
    rows = []
    for opening_month in months:
        cohort = ics[ics['Opening Month'] == opening_month]
        opening_dt = pd.to_datetime(opening_month)
        
        row = {'Cohort': opening_month, 'Size': len(cohort), 'Avg Balance': cohort['Curr Bal'].mean()}
        
        for label, offset in milestones.items():
            tag = (opening_dt + relativedelta(months=offset)).strftime('%b%y')
            swipe_col = f"{tag} Swipes"
            
            if tag in last_12_months and swipe_col in cohort.columns:
                swipes = pd.to_numeric(cohort[swipe_col], errors='coerce').fillna(0)
                active = int((swipes > 0).sum())
                row[f'{label} Active'] = active
                row[f'{label} Rate'] = active / len(cohort) if len(cohort) else 0
        
        rows.append(row)
    
    return pd.DataFrame(rows)
