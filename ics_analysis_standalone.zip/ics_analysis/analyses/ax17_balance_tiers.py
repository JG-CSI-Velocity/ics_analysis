"""Section 17: Balance Tier Distribution"""

import pandas as pd
from ..utils import get_ics_stat_o, add_balance_tier, add_total_row, BALANCE_TIER_ORDER

ANALYSIS_ID = "ax17"
ANALYSIS_NAME = "Balance Tier Distribution"
ANALYSIS_SECTION = "demographics"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics = add_balance_tier(ics, 'Curr Bal', 'Tier')
    
    dist = ics.groupby('Tier').agg(
        Count=('Curr Bal', 'count'),
        Total_Balance=('Curr Bal', 'sum'),
        Avg_Balance=('Curr Bal', 'mean')
    ).reset_index()
    
    dist['Tier'] = pd.Categorical(dist['Tier'], categories=BALANCE_TIER_ORDER, ordered=True)
    dist = dist.sort_values('Tier').reset_index(drop=True)
    dist['% of Accounts'] = dist['Count'] / dist['Count'].sum()
    
    return add_total_row(dist, 'Tier', pct_cols=['% of Accounts'])
