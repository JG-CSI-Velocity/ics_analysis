"""Section 4: ICS Stat O by Product Code"""

import pandas as pd
from ..utils import get_ics_stat_o, add_total_row

ANALYSIS_ID = "ax04"
ANALYSIS_NAME = "ICS Stat O by Product Code"
ANALYSIS_SECTION = "summary"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics['Prod Code'] = ics['Prod Code'].astype(str).str.strip().replace(['', 'nan'], 'Unknown')
    
    dist = ics['Prod Code'].value_counts().reset_index()
    dist.columns = ['Prod Code', 'Count']
    dist['% of Stat O'] = dist['Count'] / len(ics)
    
    dist = dist.sort_values('Count', ascending=False).reset_index(drop=True)
    return add_total_row(dist, 'Prod Code', pct_cols=['% of Stat O'])
