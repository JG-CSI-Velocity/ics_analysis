"""Section 22: L12M Activity Summary"""

import pandas as pd
from ..utils import get_ics_stat_o_debit, add_l12m_activity

ANALYSIS_ID = "ax22"
ANALYSIS_NAME = "L12M Activity Summary"
ANALYSIS_SECTION = "activity"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    last_12_months = context['last_12_months']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_l12m_activity(ics, last_12_months)
    
    total = len(ics)
    active = int(ics['Active in L12M'].sum())
    inactive = total - active
    total_swipes = int(ics['Total L12M Swipes'].sum())
    total_spend = float(ics['Total L12M Spend'].sum())
    
    return pd.DataFrame({
        'Metric': [
            'Total Accounts',
            'Active (L12M)',
            'Inactive (L12M)',
            'Activation Rate',
            'Total Swipes',
            'Total Spend',
            'Avg Swipes/Account',
            'Avg Spend/Account',
            'Avg Spend/Swipe'
        ],
        'Value': [
            f"{total:,}",
            f"{active:,}",
            f"{inactive:,}",
            f"{active/total:.1%}" if total else "0%",
            f"{total_swipes:,}",
            f"${total_spend:,.2f}",
            f"{total_swipes/total:.1f}" if total else "0",
            f"${total_spend/total:,.2f}" if total else "$0",
            f"${total_spend/total_swipes:.2f}" if total_swipes else "$0"
        ]
    })
