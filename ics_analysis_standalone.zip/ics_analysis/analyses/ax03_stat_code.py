"""Section 3: ICS by Status Code"""

import pandas as pd
from ..utils import get_ics_accounts, add_total_row

ANALYSIS_ID = "ax03"
ANALYSIS_NAME = "ICS by Status Code"
ANALYSIS_SECTION = "summary"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_accounts(data)
    ics['Stat Code'] = ics['Stat Code'].astype(str).str.upper().str.strip()
    
    dist = ics['Stat Code'].value_counts().reset_index()
    dist.columns = ['Stat Code', 'Count']
    dist['% of ICS'] = dist['Count'] / len(ics)
    
    # Add not in dump if provided
    ics_not_in_dump = context.get('ics_not_in_dump', 0)
    if ics_not_in_dump > 0:
        not_in = pd.DataFrame({
            'Stat Code': ['Not in Data Dump'],
            'Count': [ics_not_in_dump],
            '% of ICS': [ics_not_in_dump / (len(ics) + ics_not_in_dump)]
        })
        dist = pd.concat([dist, not_in], ignore_index=True)
    
    dist = dist.sort_values('Count', ascending=False).reset_index(drop=True)
    return add_total_row(dist, 'Stat Code', pct_cols=['% of ICS'])
