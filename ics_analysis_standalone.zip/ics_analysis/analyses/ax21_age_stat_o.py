"""Section 21: Account Age for Stat O"""

import pandas as pd
from ..utils import get_ics_stat_o, add_account_age, add_age_range, add_total_row, AGE_RANGE_ORDER

ANALYSIS_ID = "ax21"
ANALYSIS_NAME = "Account Age for Stat O"
ANALYSIS_SECTION = "demographics"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics = add_account_age(ics)
    ics = add_age_range(ics)
    
    dist = ics['Age Range'].value_counts().reset_index()
    dist.columns = ['Age Range', 'Count']
    dist['% of Stat O'] = dist['Count'] / len(ics)
    
    dist['Age Range'] = pd.Categorical(dist['Age Range'], categories=AGE_RANGE_ORDER, ordered=True)
    dist = dist.sort_values('Age Range').reset_index(drop=True)
    return add_total_row(dist, 'Age Range', pct_cols=['% of Stat O'])
