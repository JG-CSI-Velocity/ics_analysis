"""Section 26: Activity by Branch"""

import pandas as pd
from ..utils import get_ics_stat_o_debit, add_l12m_activity, add_total_row

ANALYSIS_ID = "ax26"
ANALYSIS_NAME = "Activity by Branch"
ANALYSIS_SECTION = "activity"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    last_12_months = context['last_12_months']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_l12m_activity(ics, last_12_months)
    ics['Branch'] = ics['Branch'].astype(str).str.strip()
    
    result = ics.groupby('Branch').agg(
        Accounts=('Total L12M Swipes', 'count'),
        Active=('Active in L12M', 'sum'),
        Total_Swipes=('Total L12M Swipes', 'sum'),
        Total_Spend=('Total L12M Spend', 'sum')
    ).reset_index()
    
    result['Activation %'] = result['Active'] / result['Accounts']
    result = result.sort_values('Accounts', ascending=False).reset_index(drop=True)
    
    return add_total_row(result, 'Branch')
