"""Section 9: Source by Status Code"""

import pandas as pd
from ..utils import get_ics_accounts, normalize_column

ANALYSIS_ID = "ax09"
ANALYSIS_NAME = "Source by Status Code"
ANALYSIS_SECTION = "source"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_accounts(data)
    ics = normalize_column(ics, 'Source')
    ics['Stat Code'] = ics['Stat Code'].astype(str).str.upper().str.strip()
    
    pivot = ics.groupby(['Stat Code', 'Source']).size().unstack(fill_value=0)
    pivot['Total'] = pivot.sum(axis=1)
    
    return pivot.reset_index().sort_values('Total', ascending=False).reset_index(drop=True)
