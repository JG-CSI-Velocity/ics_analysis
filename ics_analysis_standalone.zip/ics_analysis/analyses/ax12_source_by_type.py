"""Section 12: Source by Business Type"""

import pandas as pd
from ..utils import get_ics_stat_o, normalize_column

ANALYSIS_ID = "ax12"
ANALYSIS_NAME = "Source by Business Type"
ANALYSIS_SECTION = "source"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics = normalize_column(ics, 'Source')
    ics['Business?'] = ics['Business?'].astype(str).str.strip().str.title()
    
    pivot = ics.groupby(['Business?', 'Source']).size().unstack(fill_value=0)
    pivot['Total'] = pivot.sum(axis=1)
    
    return pivot.reset_index()
