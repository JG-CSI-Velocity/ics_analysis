"""Section 15: ICS Account Closures"""

import pandas as pd
from ..utils import get_ics_accounts, add_total_row

ANALYSIS_ID = "ax15"
ANALYSIS_NAME = "ICS Account Closures"
ANALYSIS_SECTION = "demographics"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_accounts(data)
    
    closed = len(ics[ics['Date Closed'].notna()])
    open_count = len(ics[ics['Date Closed'].isna()])
    
    result = pd.DataFrame({
        'Status': ['Open', 'Closed'],
        'Count': [open_count, closed],
        '% of ICS': [open_count/len(ics), closed/len(ics)]
    })
    return add_total_row(result, 'Status', pct_cols=['% of ICS'])
