"""Section 13: Source by Opening Year"""

import pandas as pd
from ..utils import get_ics_stat_o, normalize_column

ANALYSIS_ID = "ax13"
ANALYSIS_NAME = "Source by Opening Year"
ANALYSIS_SECTION = "source"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics = normalize_column(ics, 'Source')
    ics['Date Opened'] = pd.to_datetime(ics['Date Opened'], errors='coerce')
    ics['Year Opened'] = ics['Date Opened'].dt.year
    
    pivot = ics.groupby(['Year Opened', 'Source']).size().unstack(fill_value=0)
    pivot['Total'] = pivot.sum(axis=1)
    
    return pivot.reset_index().sort_values('Year Opened').reset_index(drop=True)
