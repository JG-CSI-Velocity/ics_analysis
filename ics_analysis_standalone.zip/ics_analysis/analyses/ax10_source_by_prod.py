"""Section 10: Source by Product Code"""

import pandas as pd
from ..utils import get_ics_stat_o, normalize_column

ANALYSIS_ID = "ax10"
ANALYSIS_NAME = "Source by Product Code"
ANALYSIS_SECTION = "source"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics = normalize_column(ics, 'Source')
    ics['Prod Code'] = ics['Prod Code'].astype(str).str.strip().replace(['', 'nan'], 'Unknown')
    
    pivot = ics.groupby(['Prod Code', 'Source']).size().unstack(fill_value=0)
    pivot['Total'] = pivot.sum(axis=1)
    
    return pivot.reset_index().sort_values('Total', ascending=False).reset_index(drop=True)
