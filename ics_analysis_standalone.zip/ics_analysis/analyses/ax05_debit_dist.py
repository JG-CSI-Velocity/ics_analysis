"""Section 5: ICS Stat O Debit Distribution"""

import pandas as pd
from ..utils import get_ics_stat_o, add_total_row

ANALYSIS_ID = "ax05"
ANALYSIS_NAME = "ICS Stat O Debit Distribution"
ANALYSIS_SECTION = "summary"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics['Debit?'] = ics['Debit?'].astype(str).str.strip().str.title()
    
    dist = ics['Debit?'].value_counts().reindex(['Yes', 'No'], fill_value=0).reset_index()
    dist.columns = ['Debit Card', 'Count']
    dist['% of Stat O'] = dist['Count'] / len(ics)
    
    return add_total_row(dist, 'Debit Card', pct_cols=['% of Stat O'])
