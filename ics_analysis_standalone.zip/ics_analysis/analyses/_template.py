"""
=============================================================================
ICS ANALYSIS TEMPLATE

To create a new analysis:
1. Copy this file to ax##_your_name.py (e.g., ax40_new_metric.py)
2. Update ANALYSIS_ID and ANALYSIS_NAME below
3. Write your analysis logic in run()
4. Done! Runner auto-discovers it.

IMPORTANT: 
- File name must start with "ax"
- ANALYSIS_ID must be unique
- run() must return a DataFrame
=============================================================================
"""

import pandas as pd

# Import utilities you need
from ..utils import (
    get_ics_accounts,
    get_ics_stat_o,
    get_ics_stat_o_debit,
    add_l12m_activity,
    add_balance_tier,
    add_age_range,
    add_total_row,
)

# =============================================================================
# ANALYSIS METADATA - EDIT THESE
# =============================================================================

ANALYSIS_ID = "ax00"              # Unique ID (e.g., "ax40")
ANALYSIS_NAME = "Template"        # Human-readable name
ANALYSIS_SECTION = "template"     # Group: "summary", "source", "demographics", "activity", "cohort"


# =============================================================================
# ANALYSIS FUNCTION - EDIT THIS
# =============================================================================

def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    """
    Run this analysis.
    
    Args:
        data: Source DataFrame (full dataset)
        context: Dict with:
            - client_id: str
            - client_name: str
            - cohort_start: str (e.g., "2025-01")
            - last_12_months: list (e.g., ['Feb24', 'Mar24', ...])
            - ics_not_in_dump: int
    
    Returns:
        DataFrame with results
    """
    # Example: Count ICS accounts
    ics = get_ics_accounts(data)
    
    result = pd.DataFrame({
        'Metric': ['Total ICS Accounts'],
        'Value': [len(ics)]
    })
    
    return result


# =============================================================================
# OPTIONAL: CHART FUNCTION
# =============================================================================

def chart(result: pd.DataFrame, context: dict):
    """
    Generate a chart for this analysis.
    
    Args:
        result: DataFrame returned by run()
        context: Same context dict
    
    Returns:
        matplotlib figure or None
    """
    # Return None if no chart needed
    return None
