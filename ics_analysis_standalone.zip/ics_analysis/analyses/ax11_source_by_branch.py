"""Section 11: Source by Branch"""

import pandas as pd
from ..utils import get_ics_stat_o, normalize_column

ANALYSIS_ID = "ax11"
ANALYSIS_NAME = "Source by Branch"
ANALYSIS_SECTION = "source"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics = normalize_column(ics, 'Source')
    ics['Branch'] = ics['Branch'].astype(str).str.strip()
    
    pivot = ics.groupby(['Branch', 'Source']).size().unstack(fill_value=0)
    pivot['Total'] = pivot.sum(axis=1)
    
    return pivot.reset_index().sort_values('Total', ascending=False).reset_index(drop=True)
