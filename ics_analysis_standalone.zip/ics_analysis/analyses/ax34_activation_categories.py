"""Section 34: Activation Categories"""

import pandas as pd
from dateutil.relativedelta import relativedelta
from ..utils import get_ics_stat_o_debit, add_opening_month, add_total_row

ANALYSIS_ID = "ax34"
ANALYSIS_NAME = "Activation Categories"
ANALYSIS_SECTION = "cohort"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    cohort_start = context['cohort_start']
    last_12_months = context['last_12_months']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_opening_month(ics)
    ics = ics[ics['Opening Month'] >= cohort_start].copy()
    
    categories = []
    for _, row in ics.iterrows():
        opening_dt = pd.to_datetime(row['Opening Month'])
        m1_tag = opening_dt.strftime('%b%y')
        m3_tag = (opening_dt + relativedelta(months=2)).strftime('%b%y')
        
        m1_col = f"{m1_tag} Swipes"
        m3_col = f"{m3_tag} Swipes"
        
        if m3_tag not in last_12_months:
            categories.append('Too New')
            continue
        
        m1 = pd.to_numeric(row.get(m1_col, 0), errors='coerce')
        m3 = pd.to_numeric(row.get(m3_col, 0), errors='coerce')
        m1 = 0 if pd.isna(m1) else m1
        m3 = 0 if pd.isna(m3) else m3
        
        if m1 > 0 and m3 > 0:
            categories.append('Fast Activator')
        elif m1 == 0 and m3 > 0:
            categories.append('Slow Burner')
        elif m1 > 0 and m3 == 0:
            categories.append('One and Done')
        else:
            categories.append('Never Activated')
    
    ics['Category'] = categories
    
    dist = ics['Category'].value_counts().reset_index()
    dist.columns = ['Category', 'Count']
    dist['% of Total'] = dist['Count'] / len(ics)
    
    cat_order = ['Fast Activator', 'Slow Burner', 'One and Done', 'Never Activated', 'Too New']
    dist['Category'] = pd.Categorical(dist['Category'], categories=cat_order, ordered=True)
    dist = dist.sort_values('Category').reset_index(drop=True)
    
    return add_total_row(dist, 'Category', pct_cols=['% of Total'])
