"""Section 6: Debit by Product Code"""

import pandas as pd
from ..utils import get_ics_stat_o, add_total_row

ANALYSIS_ID = "ax06"
ANALYSIS_NAME = "Debit by Product Code"
ANALYSIS_SECTION = "summary"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics['Debit?'] = ics['Debit?'].astype(str).str.strip().str.title()
    ics['Prod Code'] = ics['Prod Code'].astype(str).str.strip().replace(['', 'nan'], 'Unknown')
    
    pivot = ics.groupby(['Prod Code', 'Debit?']).size().unstack(fill_value=0)
    pivot['Total'] = pivot.sum(axis=1)
    pivot['% with Debit'] = pivot.get('Yes', 0) / pivot['Total']
    
    result = pivot.reset_index().sort_values('Total', ascending=False).reset_index(drop=True)
    return add_total_row(result, 'Prod Code')
