"""Section 25: Activity by Account Age"""

import pandas as pd
from ..utils import get_ics_stat_o_debit, add_l12m_activity, add_account_age, add_age_range, add_total_row, AGE_RANGE_ORDER

ANALYSIS_ID = "ax25"
ANALYSIS_NAME = "Activity by Account Age"
ANALYSIS_SECTION = "activity"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    last_12_months = context['last_12_months']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_l12m_activity(ics, last_12_months)
    ics = add_account_age(ics)
    ics = add_age_range(ics)
    
    result = ics.groupby('Age Range').agg(
        Accounts=('Total L12M Swipes', 'count'),
        Active=('Active in L12M', 'sum'),
        Total_Swipes=('Total L12M Swipes', 'sum'),
        Total_Spend=('Total L12M Spend', 'sum')
    ).reset_index()
    
    result['Age Range'] = pd.Categorical(result['Age Range'], categories=AGE_RANGE_ORDER, ordered=True)
    result = result.sort_values('Age Range').reset_index(drop=True)
    result['Activation %'] = result['Active'] / result['Accounts']
    
    return add_total_row(result, 'Age Range')
