"""Section 23: Monthly Activity Trend"""

import pandas as pd
from ..utils import get_ics_stat_o_debit

ANALYSIS_ID = "ax23"
ANALYSIS_NAME = "Monthly Activity Trend"
ANALYSIS_SECTION = "activity"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    last_12_months = context['last_12_months']
    ics = get_ics_stat_o_debit(data)
    
    rows = []
    for month in last_12_months:
        swipe_col = f"{month} Swipes"
        spend_col = f"{month} Spend"
        
        if swipe_col in ics.columns:
            swipes = pd.to_numeric(ics[swipe_col], errors='coerce').fillna(0)
            spend = pd.to_numeric(ics.get(spend_col, 0), errors='coerce').fillna(0)
            
            rows.append({
                'Month': month,
                'Active Accounts': int((swipes > 0).sum()),
                'Total Swipes': int(swipes.sum()),
                'Total Spend': float(spend.sum()),
                'Avg Swipes': swipes[swipes > 0].mean() if (swipes > 0).any() else 0
            })
    
    return pd.DataFrame(rows)
