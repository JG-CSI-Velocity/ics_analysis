"""
ICS Analyses - Auto-Discovery

This module auto-discovers all analysis files in this folder.

To add a new analysis:
1. Copy _template.py to ax##_your_name.py
2. Edit the ANALYSIS_ID, ANALYSIS_NAME, and run() function
3. That's it - runner will find it automatically

Analysis files must:
- Start with 'ax' (e.g., ax01_total_ics.py)
- Have an ANALYSIS_ID variable (e.g., "ax01")
- Have an ANALYSIS_NAME variable (e.g., "Total ICS Accounts")
- Have a run(data, context) function that returns a DataFrame
"""

import importlib
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def discover_analyses() -> dict:
    """
    Auto-discover all analysis modules.
    
    Returns:
        Dict of {analysis_id: module}
    """
    analyses = {}
    analyses_dir = Path(__file__).parent
    
    for file in sorted(analyses_dir.glob("ax*.py")):
        module_name = file.stem
        
        try:
            module = importlib.import_module(f".{module_name}", package="ics_analysis.analyses")
            
            # Validate required attributes
            if not hasattr(module, 'ANALYSIS_ID'):
                logger.warning(f"Skipping {module_name}: missing ANALYSIS_ID")
                continue
            if not hasattr(module, 'run'):
                logger.warning(f"Skipping {module_name}: missing run() function")
                continue
            
            analysis_id = module.ANALYSIS_ID
            analyses[analysis_id] = module
            logger.debug(f"Discovered: {analysis_id} ({module_name})")
            
        except Exception as e:
            logger.error(f"Failed to load {module_name}: {e}")
    
    return analyses


def list_analyses() -> None:
    """Print all discovered analyses."""
    analyses = discover_analyses()
    
    print("\n📋 Available Analyses:")
    print("-" * 60)
    for aid, module in sorted(analyses.items()):
        name = getattr(module, 'ANALYSIS_NAME', 'No name')
        print(f"  {aid}: {name}")
    print(f"\nTotal: {len(analyses)} analyses")
