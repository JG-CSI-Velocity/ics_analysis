"""Section 14: Account Age - ICS vs Non-ICS"""

import pandas as pd
from ..utils import add_account_age, add_age_range, AGE_RANGE_ORDER

ANALYSIS_ID = "ax14"
ANALYSIS_NAME = "Account Age - ICS vs Non-ICS"
ANALYSIS_SECTION = "demographics"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    df = data.copy()
    df['ICS Account'] = df['ICS Account'].astype(str).str.strip().str.title()
    df = add_account_age(df)
    df = add_age_range(df)
    
    pivot = df.groupby(['Age Range', 'ICS Account']).size().unstack(fill_value=0)
    pivot['Total'] = pivot.sum(axis=1)
    pivot['ICS %'] = pivot.get('Yes', 0) / pivot['Total']
    
    result = pivot.reset_index()
    result['Age Range'] = pd.Categorical(result['Age Range'], categories=AGE_RANGE_ORDER, ordered=True)
    return result.sort_values('Age Range').reset_index(drop=True)
