"""Section 36: Cohort Growth Patterns"""

import pandas as pd
from ..utils import get_ics_stat_o_debit, add_opening_month

ANALYSIS_ID = "ax36"
ANALYSIS_NAME = "Cohort Growth Patterns"
ANALYSIS_SECTION = "cohort"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    cohort_start = context['cohort_start']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_opening_month(ics)
    ics = ics[ics['Opening Month'] >= cohort_start].copy()
    
    cohorts = sorted(ics['Opening Month'].unique())
    
    rows = []
    for i, cohort in enumerate(cohorts):
        cohort_data = ics[ics['Opening Month'] == cohort]
        prev_size = len(ics[ics['Opening Month'] == cohorts[i-1]]) if i > 0 else 0
        
        rows.append({
            'Cohort': cohort,
            'New Accounts': len(cohort_data),
            'Cumulative': len(ics[ics['Opening Month'] <= cohort]),
            'Growth': len(cohort_data) - prev_size if i > 0 else len(cohort_data),
            'Growth %': (len(cohort_data) - prev_size) / prev_size if prev_size > 0 else None
        })
    
    return pd.DataFrame(rows)
