"""Section 20: Balance by Business Type"""

import pandas as pd
from ..utils import get_ics_stat_o, add_total_row

ANALYSIS_ID = "ax20"
ANALYSIS_NAME = "Balance by Business Type"
ANALYSIS_SECTION = "demographics"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics['Business?'] = ics['Business?'].astype(str).str.strip().str.title()
    
    result = ics.groupby('Business?').agg(
        Count=('Curr Bal', 'count'),
        Total_Balance=('Curr Bal', 'sum'),
        Avg_Balance=('Curr Bal', 'mean')
    ).reset_index()
    
    return add_total_row(result, 'Business?')
