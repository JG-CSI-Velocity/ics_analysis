"""Section 1: Total ICS Accounts in Dataset"""

import pandas as pd
from ..utils import get_ics_accounts

ANALYSIS_ID = "ax01"
ANALYSIS_NAME = "Total ICS Accounts"
ANALYSIS_SECTION = "summary"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    total = len(data)
    ics = len(get_ics_accounts(data))
    non_ics = total - ics
    
    return pd.DataFrame({
        'Category': ['Total Accounts', 'ICS Accounts', 'Non-ICS Accounts'],
        'Count': [total, ics, non_ics],
        '% of Total': [1.0, ics/total if total else 0, non_ics/total if total else 0]
    })
