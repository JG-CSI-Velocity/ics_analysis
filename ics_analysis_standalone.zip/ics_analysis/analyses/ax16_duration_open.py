"""Section 16: Duration Before Closing"""

import pandas as pd
from ..utils import get_ics_accounts, add_age_range, add_total_row, AGE_RANGE_ORDER

ANALYSIS_ID = "ax16"
ANALYSIS_NAME = "Duration Before Closing"
ANALYSIS_SECTION = "demographics"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_accounts(data)
    closed = ics[ics['Date Closed'].notna()].copy()
    
    if len(closed) == 0:
        return pd.DataFrame({'Note': ['No closed ICS accounts']})
    
    closed['Date Opened'] = pd.to_datetime(closed['Date Opened'], errors='coerce')
    closed['Date Closed'] = pd.to_datetime(closed['Date Closed'], errors='coerce')
    closed['Days Open'] = (closed['Date Closed'] - closed['Date Opened']).dt.days
    closed = add_age_range(closed, 'Days Open', 'Duration')
    
    dist = closed['Duration'].value_counts().reset_index()
    dist.columns = ['Duration', 'Count']
    dist['% of Closed'] = dist['Count'] / len(closed)
    
    dist['Duration'] = pd.Categorical(dist['Duration'], categories=AGE_RANGE_ORDER, ordered=True)
    dist = dist.sort_values('Duration').reset_index(drop=True)
    return add_total_row(dist, 'Duration', pct_cols=['% of Closed'])
