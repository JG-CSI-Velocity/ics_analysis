"""Section 19: Balance by Debit Status"""

import pandas as pd
from ..utils import get_ics_stat_o, add_total_row

ANALYSIS_ID = "ax19"
ANALYSIS_NAME = "Balance by Debit Status"
ANALYSIS_SECTION = "demographics"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o(data)
    ics['Debit?'] = ics['Debit?'].astype(str).str.strip().str.title()
    
    result = ics.groupby('Debit?').agg(
        Count=('Curr Bal', 'count'),
        Total_Balance=('Curr Bal', 'sum'),
        Avg_Balance=('Curr Bal', 'mean')
    ).reset_index()
    
    return add_total_row(result, 'Debit?')
