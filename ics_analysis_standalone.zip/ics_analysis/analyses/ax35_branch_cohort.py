"""Section 35: Branch Performance for Cohort"""

import pandas as pd
from ..utils import get_ics_stat_o_debit, add_opening_month, add_l12m_activity, add_total_row

ANALYSIS_ID = "ax35"
ANALYSIS_NAME = "Branch Performance for Cohort"
ANALYSIS_SECTION = "cohort"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    cohort_start = context['cohort_start']
    last_12_months = context['last_12_months']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_opening_month(ics)
    ics = ics[ics['Opening Month'] >= cohort_start].copy()
    ics = add_l12m_activity(ics, last_12_months)
    ics['Branch'] = ics['Branch'].astype(str).str.strip()
    
    result = ics.groupby('Branch').agg(
        Cohort_Accounts=('Total L12M Swipes', 'count'),
        Active=('Active in L12M', 'sum'),
        Total_Swipes=('Total L12M Swipes', 'sum'),
        Total_Spend=('Total L12M Spend', 'sum')
    ).reset_index()
    
    result['Activation %'] = result['Active'] / result['Cohort_Accounts']
    result = result.sort_values('Cohort_Accounts', ascending=False).reset_index(drop=True)
    
    return add_total_row(result, 'Branch')
