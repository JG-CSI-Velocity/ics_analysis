"""Section 24: Activity by Balance Tier"""

import pandas as pd
from ..utils import get_ics_stat_o_debit, add_l12m_activity, add_balance_tier, add_total_row, BALANCE_TIER_ORDER

ANALYSIS_ID = "ax24"
ANALYSIS_NAME = "Activity by Balance Tier"
ANALYSIS_SECTION = "activity"


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    last_12_months = context['last_12_months']
    
    ics = get_ics_stat_o_debit(data)
    ics = add_l12m_activity(ics, last_12_months)
    ics = add_balance_tier(ics, 'Curr Bal', 'Tier')
    
    result = ics.groupby('Tier').agg(
        Accounts=('Total L12M Swipes', 'count'),
        Active=('Active in L12M', 'sum'),
        Total_Swipes=('Total L12M Swipes', 'sum'),
        Total_Spend=('Total L12M Spend', 'sum')
    ).reset_index()
    
    result['Tier'] = pd.Categorical(result['Tier'], categories=BALANCE_TIER_ORDER, ordered=True)
    result = result.sort_values('Tier').reset_index(drop=True)
    result['Activation %'] = result['Active'] / result['Accounts']
    
    return add_total_row(result, 'Tier')
