"""
ICS Analysis - Configuration

Edit ICS_CLIENTS to add your clients.
"""

import pandas as pd
from datetime import datetime
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


# =============================================================================
# PATHS - EDIT THIS
# =============================================================================

BASE_PATH = Path(r"C:\Users\james.gilmore\OneDrive - Computer Services, Inc\Desktop\ARS\ARS Analysis\Raw Data\Ready for Analysis")


# =============================================================================
# CLIENTS - EDIT THIS
# =============================================================================

ICS_CLIENTS = {
    "1453": {
        "name": "Connex CU",
        "ics_cohort_start": "2025-01",
    },
    "1615": {
        "name": "Sample CU",
        "ics_cohort_start": "2025-01",
    },
    # Add more clients:
    # "1234": {
    #     "name": "Another CU",
    #     "ics_cohort_start": "2023-06",
    # },
}


# =============================================================================
# SOURCE FILE HANDLING
# =============================================================================

def get_source_file(client_id: str, year_month: str = None) -> Path:
    """
    Find the ODD source file for a client.
    
    Args:
        client_id: Client ID (e.g., "1453")
        year_month: "YYYY.MM" format. If None, finds latest.
    
    Returns:
        Path to the ODD file
        
    File pattern: {BASE_PATH}/{YYYY.MM}/{client_id}/{client_id}-{YYYY}-{MM}-{name}-ODD.xlsx
    """
    if client_id not in ICS_CLIENTS:
        raise ValueError(f"Client '{client_id}' not in config. Available: {list(ICS_CLIENTS.keys())}")
    
    client = ICS_CLIENTS[client_id]
    
    # Find year_month folder
    if year_month is None:
        year_month = find_latest_month()
    
    folder = BASE_PATH / year_month / client_id
    
    if not folder.exists():
        raise FileNotFoundError(f"Folder not found: {folder}")
    
    # Find ODD file
    pattern = f"{client_id}-*-ODD.xlsx"
    files = list(folder.glob(pattern))
    
    if not files:
        raise FileNotFoundError(f"No ODD file found in {folder} matching {pattern}")
    
    if len(files) > 1:
        logger.warning(f"Multiple ODD files found, using: {files[0].name}")
    
    return files[0]


def find_latest_month() -> str:
    """Find the most recent YYYY.MM folder."""
    folders = [f for f in BASE_PATH.iterdir() if f.is_dir() and '.' in f.name]
    
    if not folders:
        raise FileNotFoundError(f"No month folders found in {BASE_PATH}")
    
    # Sort by name (YYYY.MM sorts correctly)
    latest = sorted(folders, reverse=True)[0]
    return latest.name


def list_available_months() -> list:
    """List all available month folders."""
    folders = [f.name for f in BASE_PATH.iterdir() if f.is_dir() and '.' in f.name]
    return sorted(folders, reverse=True)


# =============================================================================
# LAST 12 MONTHS
# =============================================================================

def generate_last_12_months(reference_date: datetime = None) -> list:
    """
    Generate list of last 12 month tags like ['Feb24', 'Mar24', ..., 'Jan25'].
    """
    if reference_date is None:
        reference_date = datetime.now()
    
    end_date = pd.Timestamp(reference_date.replace(day=1)) - pd.DateOffset(days=1)
    start_date = end_date.replace(day=1) - pd.DateOffset(months=11)
    
    months = pd.date_range(start=start_date, end=end_date, freq='ME').strftime('%b%y')
    return list(months)


# =============================================================================
# REQUIRED COLUMNS
# =============================================================================

REQUIRED_COLUMNS = [
    'ICS Account',
    'Stat Code',
    'Debit?',
    'Business?',
    'Date Opened',
    'Date Closed',
    'Prod Code',
    'Branch',
    'Source',
    'Curr Bal',
    'Avg Bal',
]


def validate_data(data: pd.DataFrame) -> list:
    """
    Validate source data has required columns.
    
    Returns list of missing columns (empty if all present).
    """
    missing = [col for col in REQUIRED_COLUMNS if col not in data.columns]
    return missing
