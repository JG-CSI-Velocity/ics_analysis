# ICS Analysis

Modular, standalone ICS account analysis for credit unions.

## Setup

1. Copy `ics_analysis/` folder to your working directory
2. Edit `config.py`:
   - Update `BASE_PATH` to your data folder
   - Add your clients to `ICS_CLIENTS`

## Configuration

```python
# config.py

BASE_PATH = Path(r"C:\Users\james.gilmore\OneDrive - Computer Services, Inc\Desktop\ARS\ARS Analysis\Raw Data\Ready for Analysis")

ICS_CLIENTS = {
    "1453": {
        "name": "Connex CU",
        "ics_cohort_start": "2025-01",
    },
    "1615": {
        "name": "Another CU", 
        "ics_cohort_start": "2024-06",
    },
}
```

Source files expected at: `{BASE_PATH}/{YYYY.MM}/{client_id}/{client_id}-*-ODD.xlsx`

## Usage

```python
from ics_analysis import run_client

# Run with Excel output only
results = run_client("1453", ics_not_in_dump=80)

# Run with Excel + PowerPoint
results = run_client("1453", ics_not_in_dump=80, export_pptx=True)

# Run for specific month
results = run_client("1453", year_month="2026.01", ics_not_in_dump=80)

# Skip all exports (just get results)
results = run_client("1453", export_excel=False)
```

## Output Files

When you run with exports enabled:
- `{client_id}_ICS_Analysis_{timestamp}.xlsx` - All tables in formatted Excel
- `{client_id}_ICS_Presentation_{timestamp}.pptx` - All slides ready to edit
- `charts/` folder with rendered images

## Adding a New Analysis

1. Copy `analyses/_template.py` to `analyses/ax40_my_analysis.py`
2. Edit the file:

```python
"""Section 40: My New Analysis"""

import pandas as pd
from ..utils import get_ics_stat_o_debit

ANALYSIS_ID = "ax40"                    # Must be unique
ANALYSIS_NAME = "My New Analysis"       # Human readable
ANALYSIS_SECTION = "custom"             # Group name


def run(data: pd.DataFrame, context: dict) -> pd.DataFrame:
    ics = get_ics_stat_o_debit(data)
    
    result = pd.DataFrame({
        'Metric': ['Total'],
        'Value': [len(ics)]
    })
    
    return result
```

3. To add it to PowerPoint, edit `exports/pptx.py` and add to `SLIDE_CONFIG`:
```python
'ax40': {'type': 'table', 'title': 'My New Analysis', 'section': 'Custom'},
```

4. Done! Auto-discovered on next run.

## Project Structure

```
ics_analysis/
├── __init__.py          # Package entry
├── config.py            # Paths, clients
├── utils.py             # Shared functions
├── runner.py            # Orchestration, logging
├── analyses/            # One file per analysis
│   ├── _template.py     # Copy this for new
│   ├── ax01_total_ics.py
│   └── ...
└── exports/
    ├── excel.py         # Excel export
    ├── pptx.py          # PowerPoint + table rendering
    └── deck_builder.py  # Slide builder
```

## Current Analyses

| ID | Name | Section |
|----|------|---------|
| ax01-07 | Account Summaries | Overview |
| ax08-13 | Source Distribution | Source Analysis |
| ax14-21 | Demographics | Demographics |
| ax22-26 | Activity & KPIs | Activity |
| ax27-36 | Cohort Analysis | Cohort Analysis |

## PowerPoint Slide Types

In `exports/pptx.py`, each analysis maps to a slide type:

- `table` - Renders DataFrame as styled table image
- `bar` - Bar chart (needs `x` and `y` column names)
- `trend` - Line chart (needs `x` and `y` column names)

Example:
```python
SLIDE_CONFIG = {
    'ax01': {'type': 'table', 'title': 'Total ICS', 'section': 'Overview'},
    'ax17': {'type': 'bar', 'title': 'Balance Tiers', 'section': 'Demographics', 'x': 'Tier', 'y': 'Count'},
    'ax23': {'type': 'trend', 'title': 'Monthly Trend', 'section': 'Activity', 'x': 'Month', 'y': ['Active', 'Swipes']},
}
```
