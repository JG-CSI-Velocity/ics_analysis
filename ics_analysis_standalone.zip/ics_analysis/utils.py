"""
ICS Analysis - Utility Functions

Shared filters, metrics, and formatting.
Import these in your analysis files.
"""

import pandas as pd
import numpy as np
from typing import List


# =============================================================================
# FILTERS
# =============================================================================

def get_ics_accounts(data: pd.DataFrame) -> pd.DataFrame:
    """Filter to ICS accounts only (ICS Account = Yes)."""
    df = data.copy()
    df['ICS Account'] = df['ICS Account'].astype(str).str.strip().str.title()
    return df[df['ICS Account'] == 'Yes'].copy()


def get_ics_stat_o(data: pd.DataFrame) -> pd.DataFrame:
    """Filter to ICS accounts with Stat Code O (open accounts)."""
    df = data.copy()
    df['ICS Account'] = df['ICS Account'].astype(str).str.strip().str.title()
    df['Stat Code'] = df['Stat Code'].astype(str).str.upper().str.strip()
    return df[(df['ICS Account'] == 'Yes') & (df['Stat Code'] == 'O')].copy()


def get_ics_stat_o_debit(data: pd.DataFrame) -> pd.DataFrame:
    """Filter to ICS accounts with Stat Code O and Debit card."""
    df = data.copy()
    df['ICS Account'] = df['ICS Account'].astype(str).str.strip().str.title()
    df['Stat Code'] = df['Stat Code'].astype(str).str.upper().str.strip()
    df['Debit?'] = df['Debit?'].astype(str).str.strip().str.title()
    return df[
        (df['ICS Account'] == 'Yes') & 
        (df['Stat Code'] == 'O') & 
        (df['Debit?'] == 'Yes')
    ].copy()


def get_open_accounts(data: pd.DataFrame) -> pd.DataFrame:
    """Filter to open accounts (no close date)."""
    return data[data['Date Closed'].isna()].copy()


# =============================================================================
# ACTIVITY METRICS
# =============================================================================

def add_l12m_activity(df: pd.DataFrame, last_12_months: List[str]) -> pd.DataFrame:
    """
    Add Last 12 Months activity columns:
    - Total L12M Swipes
    - Total L12M Spend  
    - Active in L12M (bool)
    """
    df = df.copy()
    
    swipe_cols = [c for c in df.columns if 'Swipes' in c and any(m in c for m in last_12_months)]
    spend_cols = [c for c in df.columns if 'Spend' in c and any(m in c for m in last_12_months)]
    
    df['Total L12M Swipes'] = df[swipe_cols].apply(pd.to_numeric, errors='coerce').fillna(0).sum(axis=1) if swipe_cols else 0
    df['Total L12M Spend'] = df[spend_cols].apply(pd.to_numeric, errors='coerce').fillna(0).sum(axis=1) if spend_cols else 0
    df['Active in L12M'] = df['Total L12M Swipes'] > 0
    
    return df


def add_opening_month(df: pd.DataFrame) -> pd.DataFrame:
    """Add Opening Month column (YYYY-MM format)."""
    df = df.copy()
    df['Date Opened'] = pd.to_datetime(df['Date Opened'], errors='coerce')
    df['Opening Month'] = df['Date Opened'].dt.to_period('M').astype(str)
    return df


def add_account_age(df: pd.DataFrame) -> pd.DataFrame:
    """Add Account Age Days column."""
    df = df.copy()
    df['Date Opened'] = pd.to_datetime(df['Date Opened'], errors='coerce')
    df['Account Age Days'] = (pd.Timestamp.now() - df['Date Opened']).dt.days
    return df


# =============================================================================
# TIER FUNCTIONS
# =============================================================================

BALANCE_TIERS = [
    (0, '0 or Less'),
    (1000, '$0 - $1K'),
    (5000, '$1K - $5K'),
    (10000, '$5K - $10K'),
    (25000, '$10K - $25K'),
    (50000, '$25K - $50K'),
    (100000, '$50K - $100K'),
    (float('inf'), '$100K+'),
]
BALANCE_TIER_ORDER = [t[1] for t in BALANCE_TIERS]


def categorize_balance(value) -> str:
    """Assign balance tier."""
    if pd.isna(value):
        return 'Unknown'
    try:
        val = float(value)
    except:
        return 'Unknown'
    
    if val <= 0:
        return '0 or Less'
    for threshold, label in BALANCE_TIERS:
        if val < threshold:
            return label
    return '$100K+'


def add_balance_tier(df: pd.DataFrame, col: str = 'Curr Bal', new_col: str = 'Balance Tier') -> pd.DataFrame:
    """Add balance tier column."""
    df = df.copy()
    df[new_col] = df[col].apply(categorize_balance)
    df[new_col] = pd.Categorical(df[new_col], categories=BALANCE_TIER_ORDER, ordered=True)
    return df


AGE_RANGES = [
    (30, '0-1 month'),
    (90, '1-3 months'),
    (180, '3-6 months'),
    (365, '6-12 months'),
    (730, '1-2 years'),
    (1825, '2-5 years'),
    (3650, '5-10 years'),
    (float('inf'), '10+ years'),
]
AGE_RANGE_ORDER = [r[1] for r in AGE_RANGES]


def categorize_age(days) -> str:
    """Assign age range."""
    if pd.isna(days):
        return 'Unknown'
    try:
        val = float(days)
    except:
        return 'Unknown'
    
    if val < 0:
        return 'Unknown'
    for threshold, label in AGE_RANGES:
        if val < threshold:
            return label
    return '10+ years'


def add_age_range(df: pd.DataFrame, col: str = 'Account Age Days', new_col: str = 'Age Range') -> pd.DataFrame:
    """Add age range column."""
    df = df.copy()
    df[new_col] = df[col].apply(categorize_age)
    df[new_col] = pd.Categorical(df[new_col], categories=AGE_RANGE_ORDER, ordered=True)
    return df


# =============================================================================
# TABLE HELPERS
# =============================================================================

def add_total_row(df: pd.DataFrame, label_col: str, label: str = 'Total', pct_cols: List[str] = None) -> pd.DataFrame:
    """
    Add total row to summary table.
    
    Args:
        df: DataFrame
        label_col: Column for "Total" label
        label: Text for label (default "Total")
        pct_cols: Columns that are percentages (will be set to 1.0)
    """
    df = df.copy()
    pct_cols = pct_cols or []
    
    total = {label_col: label}
    for col in df.columns:
        if col == label_col:
            continue
        if col in pct_cols:
            total[col] = 1.0
        elif pd.api.types.is_numeric_dtype(df[col]):
            total[col] = df[col].sum()
        else:
            total[col] = ''
    
    return pd.concat([df, pd.DataFrame([total])], ignore_index=True)


def normalize_column(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Clean string column: strip, title case, replace blanks with Unknown."""
    df = df.copy()
    df[col] = df[col].astype(str).str.strip().str.title()
    df[col] = df[col].replace(['', 'Nan', 'None'], 'Unknown')
    return df
