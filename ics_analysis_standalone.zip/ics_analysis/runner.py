"""
ICS Analysis - Runner

Discovers and runs all analyses with logging and error handling.
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

import pandas as pd

from .config import (
    ICS_CLIENTS, 
    get_source_file, 
    generate_last_12_months, 
    validate_data,
    find_latest_month
)
from .analyses import discover_analyses


# =============================================================================
# LOGGING SETUP
# =============================================================================

def setup_logging(log_file: str = None, level: int = logging.INFO) -> logging.Logger:
    """Configure logging to console and optional file."""
    logger = logging.getLogger('ics_analysis')
    logger.setLevel(level)
    
    # Clear existing handlers
    logger.handlers = []
    
    # Console handler
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(level)
    console_fmt = logging.Formatter('%(message)s')
    console.setFormatter(console_fmt)
    logger.addHandler(console)
    
    # File handler (if specified)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_fmt = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s')
        file_handler.setFormatter(file_fmt)
        logger.addHandler(file_handler)
    
    return logger


# =============================================================================
# ANALYSIS RUNNER
# =============================================================================

class AnalysisRunner:
    """Runs ICS analyses with logging and error handling."""
    
    def __init__(self, client_id: str, year_month: str = None, ics_not_in_dump: int = 0):
        """
        Initialize runner.
        
        Args:
            client_id: Client ID (must be in config)
            year_month: "YYYY.MM" folder (None = latest)
            ics_not_in_dump: ICS accounts not in data dump
        """
        self.client_id = client_id
        self.year_month = year_month or find_latest_month()
        self.ics_not_in_dump = ics_not_in_dump
        
        # Validate client
        if client_id not in ICS_CLIENTS:
            available = ", ".join(ICS_CLIENTS.keys())
            raise ValueError(f"Client '{client_id}' not found. Available: {available}")
        
        self.client = ICS_CLIENTS[client_id]
        self.logger = logging.getLogger('ics_analysis')
        
        # Results storage
        self.data = None
        self.results: Dict[str, pd.DataFrame] = {}
        self.errors: Dict[str, str] = {}
        self.context: Dict[str, Any] = {}
    
    def load_data(self) -> bool:
        """Load source data."""
        try:
            source_file = get_source_file(self.client_id, self.year_month)
            self.logger.info(f"📂 Loading: {source_file.name}")
            
            self.data = pd.read_excel(source_file)
            self.logger.info(f"   ✅ Loaded {len(self.data):,} rows, {len(self.data.columns)} columns")
            
            # Validate
            missing = validate_data(self.data)
            if missing:
                self.logger.error(f"   ❌ Missing columns: {missing}")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Failed to load data: {e}")
            return False
    
    def build_context(self) -> dict:
        """Build context dict passed to each analysis."""
        self.context = {
            'client_id': self.client_id,
            'client_name': self.client['name'],
            'cohort_start': self.client['ics_cohort_start'],
            'last_12_months': generate_last_12_months(),
            'ics_not_in_dump': self.ics_not_in_dump,
            'year_month': self.year_month,
        }
        return self.context
    
    def run_all(self) -> Dict[str, pd.DataFrame]:
        """Run all discovered analyses."""
        self.logger.info("")
        self.logger.info("=" * 70)
        self.logger.info("🏦 ICS ANALYSIS")
        self.logger.info("=" * 70)
        self.logger.info(f"   Client: {self.client['name']} ({self.client_id})")
        self.logger.info(f"   Month: {self.year_month}")
        self.logger.info(f"   Cohort Start: {self.client['ics_cohort_start']}")
        self.logger.info(f"   ICS Not in Dump: {self.ics_not_in_dump}")
        
        # Load data
        if not self.load_data():
            return {}
        
        # Build context
        self.build_context()
        self.logger.info(f"   L12M: {self.context['last_12_months'][0]} → {self.context['last_12_months'][-1]}")
        
        # Discover analyses
        analyses = discover_analyses()
        self.logger.info(f"\n📋 Found {len(analyses)} analyses")
        self.logger.info("-" * 70)
        
        # Run each analysis
        for analysis_id, module in sorted(analyses.items()):
            name = getattr(module, 'ANALYSIS_NAME', analysis_id)
            
            try:
                result = module.run(self.data, self.context)
                self.results[analysis_id] = result
                
                rows = len(result) if isinstance(result, pd.DataFrame) else 0
                self.logger.info(f"   ✅ {analysis_id}: {name} ({rows} rows)")
                
            except Exception as e:
                self.errors[analysis_id] = str(e)
                self.logger.error(f"   ❌ {analysis_id}: {name} - {e}")
        
        # Summary
        self.logger.info("-" * 70)
        self.logger.info(f"✅ Completed: {len(self.results)} analyses")
        if self.errors:
            self.logger.warning(f"⚠️  Failed: {len(self.errors)} analyses")
        
        return self.results
    
    def run_one(self, analysis_id: str) -> Optional[pd.DataFrame]:
        """Run a single analysis by ID."""
        analyses = discover_analyses()
        
        if analysis_id not in analyses:
            self.logger.error(f"❌ Analysis '{analysis_id}' not found")
            return None
        
        if self.data is None:
            self.load_data()
        
        if not self.context:
            self.build_context()
        
        module = analyses[analysis_id]
        try:
            result = module.run(self.data, self.context)
            self.results[analysis_id] = result
            return result
        except Exception as e:
            self.logger.error(f"❌ {analysis_id} failed: {e}")
            return None
    
    def get_summary(self) -> dict:
        """Get executive summary metrics."""
        from .utils import get_ics_accounts, get_ics_stat_o, get_ics_stat_o_debit, add_l12m_activity
        
        ics = get_ics_accounts(self.data)
        ics_o = get_ics_stat_o(self.data)
        ics_od = get_ics_stat_o_debit(self.data)
        ics_od = add_l12m_activity(ics_od, self.context['last_12_months'])
        
        return {
            'client': self.client['name'],
            'client_id': self.client_id,
            'month': self.year_month,
            'total_accounts': len(self.data),
            'ics_accounts': len(ics),
            'ics_stat_o': len(ics_o),
            'ics_with_debit': len(ics_od),
            'active_l12m': int(ics_od['Active in L12M'].sum()),
            'activation_rate': ics_od['Active in L12M'].mean(),
            'total_swipes': int(ics_od['Total L12M Swipes'].sum()),
            'total_spend': float(ics_od['Total L12M Spend'].sum()),
        }
    
    def print_summary(self):
        """Print formatted executive summary."""
        s = self.get_summary()
        
        self.logger.info("")
        self.logger.info("=" * 70)
        self.logger.info("📊 EXECUTIVE SUMMARY")
        self.logger.info("=" * 70)
        self.logger.info(f"   Client: {s['client']} ({s['client_id']})")
        self.logger.info(f"   Month: {s['month']}")
        self.logger.info("")
        self.logger.info("   Portfolio:")
        self.logger.info(f"      Total Accounts:      {s['total_accounts']:>12,}")
        self.logger.info(f"      ICS Accounts:        {s['ics_accounts']:>12,}")
        self.logger.info(f"      ICS Stat O:          {s['ics_stat_o']:>12,}")
        self.logger.info(f"      ICS with Debit:      {s['ics_with_debit']:>12,}")
        self.logger.info("")
        self.logger.info("   Activity (L12M):")
        self.logger.info(f"      Active Accounts:     {s['active_l12m']:>12,}")
        self.logger.info(f"      Activation Rate:     {s['activation_rate']:>12.1%}")
        self.logger.info(f"      Total Swipes:        {s['total_swipes']:>12,}")
        self.logger.info(f"      Total Spend:         ${s['total_spend']:>11,.2f}")
        self.logger.info("=" * 70)


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def run_client(
    client_id: str,
    year_month: str = None,
    ics_not_in_dump: int = 0,
    export_excel: bool = True,
    export_pptx: bool = False,
    log_file: str = None,
    template_path: str = None
) -> Dict[str, pd.DataFrame]:
    """
    Run ICS analysis for a client.
    
    Args:
        client_id: Client ID from config
        year_month: "YYYY.MM" folder (None = latest)
        ics_not_in_dump: Manual count for this month
        export_excel: Save to Excel
        export_pptx: Save to PowerPoint
        log_file: Optional log file path
        template_path: PowerPoint template path (optional)
    
    Returns:
        Dict of analysis results
    """
    logger = setup_logging(log_file)
    
    runner = AnalysisRunner(client_id, year_month, ics_not_in_dump)
    results = runner.run_all()
    runner.print_summary()
    
    if not results:
        return results
    
    # Get output folder
    source_file = get_source_file(client_id, year_month or runner.year_month)
    output_folder = Path(source_file).parent
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    
    # Export to Excel
    if export_excel:
        from .exports.excel import export_to_excel
        excel_path = output_folder / f"{client_id}_ICS_Analysis_{timestamp}.xlsx"
        export_to_excel(results, excel_path, runner.get_summary())
        logger.info(f"\n📁 Excel saved: {excel_path}")
    
    # Export to PowerPoint
    if export_pptx:
        from .exports.pptx import export_to_pptx
        pptx_path = output_folder / f"{client_id}_ICS_Presentation_{timestamp}.pptx"
        export_to_pptx(
            results=results,
            output_path=str(pptx_path),
            summary=runner.get_summary(),
            template_path=template_path
        )
        logger.info(f"📁 PowerPoint saved: {pptx_path}")
    
    return results


def list_clients():
    """Print configured clients."""
    print("\n📋 Configured ICS Clients:")
    print("-" * 50)
    for cid, cfg in ICS_CLIENTS.items():
        print(f"   {cid}: {cfg['name']} (cohort: {cfg['ics_cohort_start']})")


def list_analyses():
    """Print available analyses."""
    from .analyses import list_analyses as _list
    _list()
