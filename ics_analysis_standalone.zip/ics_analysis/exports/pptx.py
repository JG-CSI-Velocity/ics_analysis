"""
ICS Analysis - PowerPoint Export

Renders analysis results as slides and builds a PowerPoint deck.
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend

from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

from .deck_builder import (
    SlideContent, DeckBuilder, DECK_CONFIG,
    make_figure, apply_matplotlib_defaults
)


# =============================================================================
# TABLE RENDERING
# =============================================================================

def render_table_image(
    df: pd.DataFrame,
    output_path: str,
    title: str = None,
    figsize: tuple = (10, 6),
    dpi: int = 150
) -> str:
    """
    Render a DataFrame as a styled table image.
    
    Args:
        df: DataFrame to render
        output_path: Where to save the PNG
        title: Optional title above table
        figsize: Figure size (width, height) in inches
        dpi: Resolution
    
    Returns:
        Path to saved image
    """
    # Estimate figure height based on rows
    n_rows = len(df) + 1  # +1 for header
    row_height = 0.4
    min_height = 2
    estimated_height = max(min_height, n_rows * row_height + 1)
    
    # Adjust figsize
    actual_figsize = (figsize[0], min(estimated_height, figsize[1]))
    
    fig, ax = plt.subplots(figsize=actual_figsize)
    ax.axis('off')
    
    # Format DataFrame for display
    display_df = df.copy()
    for col in display_df.columns:
        if display_df[col].dtype == 'float64':
            # Check if it looks like a percentage (values between 0 and 1)
            if display_df[col].max() <= 1.0 and display_df[col].min() >= 0:
                display_df[col] = display_df[col].apply(lambda x: f"{x:.1%}" if pd.notna(x) else "")
            else:
                display_df[col] = display_df[col].apply(lambda x: f"{x:,.2f}" if pd.notna(x) else "")
        elif display_df[col].dtype == 'int64':
            display_df[col] = display_df[col].apply(lambda x: f"{x:,}" if pd.notna(x) else "")
    
    # Create table
    table = ax.table(
        cellText=display_df.values,
        colLabels=display_df.columns,
        cellLoc='center',
        loc='center',
        colColours=['#4472C4'] * len(display_df.columns)
    )
    
    # Style the table
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1.2, 1.5)
    
    # Style header row
    for i, col in enumerate(display_df.columns):
        cell = table[(0, i)]
        cell.set_text_props(weight='bold', color='white')
        cell.set_facecolor('#4472C4')
    
    # Alternate row colors
    for i in range(len(display_df)):
        for j in range(len(display_df.columns)):
            cell = table[(i + 1, j)]
            if i % 2 == 0:
                cell.set_facecolor('#D9E2F3')
            else:
                cell.set_facecolor('white')
            
            # Bold total row
            if i == len(display_df) - 1 and str(display_df.iloc[i, 0]).lower() == 'total':
                cell.set_text_props(weight='bold')
                cell.set_facecolor('#B4C6E7')
    
    # Add title if provided
    if title:
        ax.set_title(title, fontsize=12, fontweight='bold', pad=20)
    
    plt.tight_layout()
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close(fig)
    
    return output_path


def render_bar_chart(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    output_path: str,
    title: str = None,
    figsize: tuple = (10, 6),
    dpi: int = 150,
    horizontal: bool = False,
    color: str = '#4472C4'
) -> str:
    """
    Render a simple bar chart.
    
    Args:
        df: DataFrame with data
        x_col: Column for x-axis (categories)
        y_col: Column for y-axis (values)
        output_path: Where to save
        title: Chart title
        figsize: Figure size
        dpi: Resolution
        horizontal: If True, horizontal bars
        color: Bar color
    
    Returns:
        Path to saved image
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    x = df[x_col].astype(str)
    y = pd.to_numeric(df[y_col], errors='coerce').fillna(0)
    
    if horizontal:
        ax.barh(x, y, color=color)
        ax.set_xlabel(y_col)
    else:
        ax.bar(x, y, color=color)
        ax.set_ylabel(y_col)
        plt.xticks(rotation=45, ha='right')
    
    if title:
        ax.set_title(title, fontsize=12, fontweight='bold')
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    plt.tight_layout()
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    
    return output_path


def render_trend_chart(
    df: pd.DataFrame,
    x_col: str,
    y_cols: List[str],
    output_path: str,
    title: str = None,
    figsize: tuple = (10, 5),
    dpi: int = 150
) -> str:
    """
    Render a line chart for trends.
    
    Args:
        df: DataFrame with data
        x_col: Column for x-axis
        y_cols: Columns to plot as lines
        output_path: Where to save
        title: Chart title
    
    Returns:
        Path to saved image
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    x = df[x_col].astype(str)
    
    colors = ['#4472C4', '#ED7D31', '#A5A5A5', '#FFC000', '#5B9BD5']
    
    for i, col in enumerate(y_cols):
        y = pd.to_numeric(df[col], errors='coerce').fillna(0)
        ax.plot(x, y, marker='o', color=colors[i % len(colors)], label=col, linewidth=2)
    
    if title:
        ax.set_title(title, fontsize=12, fontweight='bold')
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    plt.xticks(rotation=45, ha='right')
    
    if len(y_cols) > 1:
        ax.legend(loc='upper left', frameon=False)
    
    plt.tight_layout()
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    
    return output_path


# =============================================================================
# SLIDE DEFINITIONS
# =============================================================================

# Define how each analysis should be rendered
SLIDE_CONFIG = {
    # Summary section - tables
    'ax01': {'type': 'table', 'title': 'Total ICS Accounts', 'section': 'Overview'},
    'ax02': {'type': 'table', 'title': 'ICS in Open Accounts', 'section': 'Overview'},
    'ax03': {'type': 'table', 'title': 'ICS by Status Code', 'section': 'Overview'},
    'ax04': {'type': 'table', 'title': 'Product Code Distribution', 'section': 'Overview'},
    'ax05': {'type': 'table', 'title': 'Debit Card Distribution', 'section': 'Overview'},
    'ax06': {'type': 'table', 'title': 'Debit by Product Code', 'section': 'Overview'},
    'ax07': {'type': 'table', 'title': 'Debit by Branch', 'section': 'Overview'},
    
    # Source section
    'ax08': {'type': 'bar', 'title': 'Source Distribution', 'section': 'Source Analysis', 'x': 'Source', 'y': 'Count'},
    'ax09': {'type': 'table', 'title': 'Source by Status Code', 'section': 'Source Analysis'},
    'ax10': {'type': 'table', 'title': 'Source by Product Code', 'section': 'Source Analysis'},
    'ax11': {'type': 'table', 'title': 'Source by Branch', 'section': 'Source Analysis'},
    'ax12': {'type': 'table', 'title': 'Source by Business Type', 'section': 'Source Analysis'},
    'ax13': {'type': 'table', 'title': 'Source by Opening Year', 'section': 'Source Analysis'},
    
    # Demographics section
    'ax14': {'type': 'table', 'title': 'Account Age - ICS vs Non-ICS', 'section': 'Demographics'},
    'ax15': {'type': 'table', 'title': 'Account Closures', 'section': 'Demographics'},
    'ax16': {'type': 'table', 'title': 'Duration Before Closing', 'section': 'Demographics'},
    'ax17': {'type': 'bar', 'title': 'Balance Tier Distribution', 'section': 'Demographics', 'x': 'Tier', 'y': 'Count'},
    'ax18': {'type': 'table', 'title': 'Balance by Status Code', 'section': 'Demographics'},
    'ax19': {'type': 'table', 'title': 'Balance by Debit Status', 'section': 'Demographics'},
    'ax20': {'type': 'table', 'title': 'Balance by Business Type', 'section': 'Demographics'},
    'ax21': {'type': 'bar', 'title': 'Account Age Distribution', 'section': 'Demographics', 'x': 'Age Range', 'y': 'Count'},
    
    # Activity section
    'ax22': {'type': 'table', 'title': 'L12M Activity Summary', 'section': 'Activity'},
    'ax23': {'type': 'trend', 'title': 'Monthly Activity Trend', 'section': 'Activity', 'x': 'Month', 'y': ['Active Accounts', 'Total Swipes']},
    'ax24': {'type': 'table', 'title': 'Activity by Balance Tier', 'section': 'Activity'},
    'ax25': {'type': 'table', 'title': 'Activity by Account Age', 'section': 'Activity'},
    'ax26': {'type': 'table', 'title': 'Activity by Branch', 'section': 'Activity'},
    
    # Cohort section
    'ax27': {'type': 'table', 'title': 'Cohort Activation Analysis', 'section': 'Cohort Analysis'},
    'ax28': {'type': 'table', 'title': 'Cohort Swipes Heatmap', 'section': 'Cohort Analysis'},
    'ax29': {'type': 'table', 'title': 'Cohort Spend Heatmap', 'section': 'Cohort Analysis'},
    'ax34': {'type': 'bar', 'title': 'Activation Categories', 'section': 'Cohort Analysis', 'x': 'Category', 'y': 'Count'},
    'ax35': {'type': 'table', 'title': 'Branch Performance - Cohort', 'section': 'Cohort Analysis'},
    'ax36': {'type': 'table', 'title': 'Cohort Growth Patterns', 'section': 'Cohort Analysis'},
}


# =============================================================================
# DECK BUILDER
# =============================================================================

def build_deck(
    results: Dict[str, pd.DataFrame],
    summary: dict,
    output_path: str,
    template_path: str = None,
    chart_dir: str = None
) -> str:
    """
    Build PowerPoint deck from analysis results.
    
    Args:
        results: Dict of {analysis_id: DataFrame}
        summary: Executive summary dict
        output_path: Where to save the .pptx
        template_path: Path to PowerPoint template
        chart_dir: Directory for temporary chart images
    
    Returns:
        Path to created PowerPoint
    """
    output_path = Path(output_path)
    
    # Setup chart directory
    if chart_dir is None:
        chart_dir = output_path.parent / "charts"
    chart_dir = Path(chart_dir)
    chart_dir.mkdir(parents=True, exist_ok=True)
    
    # Use default template if not specified
    if template_path is None:
        template_path = DECK_CONFIG['template_path']
    
    # Collect slides
    slides = []
    current_section = None
    
    # Title slide
    slides.append(SlideContent(
        slide_type='title',
        title=f"{summary['client']}\n{'─' * 20}\n{summary['month']} ICS Analysis",
        layout_index=1
    ))
    
    # Process each analysis
    for analysis_id in sorted(results.keys()):
        if analysis_id not in SLIDE_CONFIG:
            continue
        
        config = SLIDE_CONFIG[analysis_id]
        df = results[analysis_id]
        
        # Skip empty results
        if df is None or (isinstance(df, pd.DataFrame) and len(df) == 0):
            continue
        
        # Skip if it's a "Note" result
        if isinstance(df, pd.DataFrame) and 'Note' in df.columns:
            continue
        
        # Add section divider if new section
        if config.get('section') and config['section'] != current_section:
            current_section = config['section']
            slides.append(SlideContent(
                slide_type='section',
                title=current_section,
                layout_index=2
            ))
        
        # Render the visual
        chart_path = chart_dir / f"{analysis_id}.png"
        
        if config['type'] == 'table':
            render_table_image(df, str(chart_path), title=None)
        
        elif config['type'] == 'bar':
            # Filter out total row for charts
            plot_df = df[~df.iloc[:, 0].astype(str).str.lower().eq('total')].copy()
            if len(plot_df) > 0:
                render_bar_chart(
                    plot_df,
                    x_col=config['x'],
                    y_col=config['y'],
                    output_path=str(chart_path),
                    title=None
                )
            else:
                render_table_image(df, str(chart_path), title=None)
        
        elif config['type'] == 'trend':
            render_trend_chart(
                df,
                x_col=config['x'],
                y_cols=config['y'],
                output_path=str(chart_path),
                title=None
            )
        
        # Create slide
        slides.append(SlideContent(
            slide_type='screenshot',
            title=config['title'],
            images=[str(chart_path)],
            layout_index=5
        ))
    
    # Build the deck
    builder = DeckBuilder(template_path)
    builder.build(slides, str(output_path))
    
    print(f"✅ Created {len(slides)} slides: {output_path}")
    
    return str(output_path)


def export_to_pptx(
    results: Dict[str, pd.DataFrame],
    output_path: str,
    summary: dict,
    template_path: str = None
) -> str:
    """
    Convenience wrapper for build_deck.
    
    Args:
        results: Analysis results from runner
        output_path: Where to save
        summary: Summary dict from runner
        template_path: Template path (optional)
    
    Returns:
        Path to created file
    """
    return build_deck(
        results=results,
        summary=summary,
        output_path=output_path,
        template_path=template_path
    )
