"""
deck_builder.py
---------------
PowerPoint automation for client report generation.

This module provides:
    - DECK_CONFIG: Global configuration dictionary for all settings
    - SlideContent: Dataclass to define what goes on each slide
    - DeckBuilder: Class that assembles slides into a PowerPoint deck
    - setup_slide_helpers(): Initialize helpers for Jupyter notebooks
    - make_figure(): Create consistently-sized matplotlib figures
    - apply_matplotlib_defaults(): Set global chart styling

Basic Usage:
    from deck_builder import (
        SlideContent, DeckBuilder, setup_slide_helpers,
        make_figure, apply_matplotlib_defaults, DECK_CONFIG
    )
    
    # Configure
    DECK_CONFIG['template_path'] = 'template.pptx'
    DECK_CONFIG['layout_chart'] = [5, 6, 7]
    
    # Setup
    slides, add_chart_slide, add_section, add_multi_chart_slide = setup_slide_helpers(chart_dir)
    apply_matplotlib_defaults()
    
    # Create slides
    fig, ax = make_figure('single')
    ax.plot(data)
    add_chart_slide(fig, 'chart.png', 'My Chart')
    
    # Build deck
    builder = DeckBuilder(DECK_CONFIG['template_path'])
    builder.build(slides, 'output.pptx')

Dependencies:
    pip install python-pptx matplotlib
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, List, Dict, Tuple, Callable
from itertools import cycle
import matplotlib.pyplot as plt


# =============================================================================
# GLOBAL CONFIGURATION
# =============================================================================
# 
# This dictionary contains all configurable settings. Import it and modify
# values before calling setup_slide_helpers().
#
# Example:
#     from deck_builder import DECK_CONFIG
#     DECK_CONFIG['dpi'] = 200
#     DECK_CONFIG['layout_chart'] = [5, 6]
#
# =============================================================================

DECK_CONFIG = {
    # -------------------------------------------------------------------------
    # CHART EXPORT SETTINGS
    # Control how matplotlib figures are saved to PNG files
    # -------------------------------------------------------------------------
    
    'dpi': 150,
    # Resolution in dots per inch
    # - 100: Smaller files, okay for screen viewing
    # - 150: Good balance of quality and file size (default)
    # - 200-300: High quality for print or detailed charts
    
    'fig_facecolor': 'white',
    # Background color for saved chart images
    # - 'white': Standard, works with most templates
    # - 'transparent': Use if your template has colored backgrounds
    # - Any color name or hex code: '#f0f0f0', 'lightgray', etc.
    
    # -------------------------------------------------------------------------
    # FIGURE SIZES
    # Default dimensions (width, height) in inches for make_figure()
    # Adjust these to match your template's content areas
    # -------------------------------------------------------------------------
    
    'fig_single': (10, 6),
    # Full-width chart - standard analysis slide
    # Fills most of the slide width with comfortable margins
    
    'fig_double': (6, 4),
    # Side-by-side charts - two charts on one slide
    # Narrower to fit two horizontally
    
    'fig_with_kpi': (8, 6),
    # Chart with KPIs - leaves room on right for text callouts
    # Slightly narrower than single
    
    'fig_wide': (12, 5),
    # Extra wide - good for timelines, long trends, many categories
    # May extend to slide edges
    
    'fig_square': (7, 7),
    # Square aspect ratio - correlation matrices, scatter plots
    # Centers well on slide
    
    # -------------------------------------------------------------------------
    # TEMPLATE LAYOUTS - CSI Template (Updated)
    # -------------------------------------------------------------------------
    # Available layouts:
    #   0: Cover / Intro - Slide 1
    #   1: Cover / Intro - Slide 2      <- Title slide (text on left)
    #   2: Divider - Slide 2            <- Section divider
    #   3: Divider - Slide 3
    #   4: Analysis - Slide 1           <- Single chart
    #   5: Analysis - Slide 2           <- Single chart
    #   6: Analysis - Slide 3 - Split   <- Side-by-side
    #   7: Analysis - Slide 4 - Split   <- Side-by-side
    #   8: Analysis - Slide 5 - Thirds  <- Three charts
    #   9: Analysis - Slide 6 - Main    <- Single chart
    #   10: Analysis - Slide 7 - Stacked Two  <- Chart on right 2/3
    #   11: Analysis - Slide 8 - Blank  <- Flexible
    #   12: Analysis - Slide 11 - Header1
    #   13: Analysis - Slide 11 - Header2
    # -------------------------------------------------------------------------
    
    'layout_title': 1,
    # Cover / Intro - Slide 2 (text box on left, vertically centered)
    
    'layout_title_alt': 0,
    # Cover / Intro - Slide 1 (alternative)
    
    'layout_section': 2,
    # Divider - Slide 2
    
    'layout_chart': [4, 5, 9, 11],
    # Single chart layouts - cycles through these
    
    'layout_split': [6, 7],
    # Side-by-side chart layouts
    
    'layout_stacked': 10,
    # Chart on right two-thirds of slide
    
    'layout_thirds': 8,
    # Three charts layout
    
    # -------------------------------------------------------------------------
    # LAYOUT-SPECIFIC POSITIONING (in inches)
    # These override the class defaults for specific layouts
    # -------------------------------------------------------------------------
    
    'positioning': {
        # Layouts 4, 5, 9, 11 - Single chart
        'single_default': {
            'left': 0.5,
            'top': 2.5,
            'width': 6,
        },
        
        # Layout 10 - Chart on right two-thirds
        'stacked_right': {
            'left': 5.5,
            'top': 2.0,
            'width': 6,
        },
        
        # Layout 6 - Side by side
        'split_standard': {
            'top': 2.5,
            'left_pos': 2.3,
            'right_pos': 7.0,
            'width': 4.5,
        },
        
        # Layout 7 - Side by side (spaced out)
        'split_spaced': {
            'top': 2.5,
            'left_pos': 0.5,
            'right_pos': 7.5,
            'width': 4.5,
        },
    },
    
    # -------------------------------------------------------------------------
    # KPI TEXT FORMATTING
    # Font sizes for KPI callout boxes (screenshot_kpi slides)
    # -------------------------------------------------------------------------
    
    'kpi_value_size': 28,
    # Point size for the KPI value (the big number)
    # Example: "$1.2M" or "+15%"
    
    'kpi_label_size': 12,
    # Point size for the KPI label (description below the number)
    # Example: "Total Revenue" or "Growth Rate"
    
    # -------------------------------------------------------------------------
    # PATHS
    # Default file paths (override as needed)
    # -------------------------------------------------------------------------
    
    'template_path': r'C:\Users\james.gilmore\OneDrive - Computer Services, Inc\Desktop\ARS\ARS Analysis\Presentations\Blank Template\Template12.25.pptx',
    # Path to your branded PowerPoint template
    # Contains the slide layouts you'll use
}


# =============================================================================
# SLIDE CONTENT DEFINITION
# =============================================================================

@dataclass
class SlideContent:
    """
    Container for all information needed to build a single slide.
    
    This dataclass holds the data for one slide. You create SlideContent
    objects and add them to a list, then DeckBuilder processes the list
    to create the actual PowerPoint.
    
    Attributes
    ----------
    slide_type : str
        Determines which builder method creates this slide.
        Options:
            'title'           - Title slide with main title and subtitle
            'section'         - Section divider with large centered text
            'screenshot'      - Single image, nearly full width
            'screenshot_kpi'  - Image on left, KPI callouts on right
            'multi_screenshot'- Two images side by side
            'summary'         - 3x3 grid of bullet points
    
    title : str
        Text displayed in the slide's title area.
        For section slides, this is the large centered text.
    
    images : list of str, optional
        File paths to chart/screenshot PNG images.
        - 'screenshot': uses images[0] only
        - 'screenshot_kpi': uses images[0] only
        - 'multi_screenshot': uses images[0] and images[1]
    
    kpis : dict, optional
        Key-value pairs for KPI callouts.
        Keys are labels, values are the displayed numbers/text.
        Example: {"Total Revenue": "$1.2M", "Growth": "+5.2%"}
        For title slides, use {"subtitle": "January 2025"}
    
    bullets : list of str, optional
        Text items for summary slides. Up to 9 items, displayed in 3x3 grid.
        Order: [row1-col1, row1-col2, row1-col3, row2-col1, ...]
    
    layout_index : int, default 5
        Index of slide layout from template to use.
        Run inspect_template() to see available layouts.
    
    Examples
    --------
    # Title slide
    SlideContent('title', 'Q1 Report', kpis={"subtitle": "January 2025"}, layout_index=0)
    
    # Section divider
    SlideContent('section', 'Financial Analysis', layout_index=2)
    
    # Single chart
    SlideContent('screenshot', 'Revenue Trend', images=['revenue.png'])
    
    # Chart with KPIs
    SlideContent('screenshot_kpi', 'Performance',
                 images=['perf.png'],
                 kpis={"Growth": "+15%", "Total": "$2.1M"})
    
    # Two charts side by side
    SlideContent('multi_screenshot', 'Comparison',
                 images=['chart1.png', 'chart2.png'])
    
    # Summary with 9 bullets
    SlideContent('summary', 'Key Takeaways',
                 bullets=["Point 1", "Point 2", ..., "Point 9"])
    """
    slide_type: str
    title: str
    images: Optional[List[str]] = None
    kpis: Optional[Dict[str, str]] = None
    bullets: Optional[List[str]] = None
    layout_index: int = 5


# =============================================================================
# DECK BUILDER CLASS
# =============================================================================

class DeckBuilder:
    """
    Assembles SlideContent objects into a PowerPoint presentation.
    
    Uses a branded template file and creates slides based on each
    SlideContent's slide_type. All positioning values are defined as
    class constants and can be adjusted to match your template.
    
    Attributes (Class Constants)
    ----------------------------
    Spacing values in inches - adjust these to match your template:
    
    SINGLE_IMG_*      : Position/size for full-width screenshots
    MULTI_IMG_*       : Position/size for side-by-side screenshots
    KPI_IMG_*         : Position/size for screenshot in screenshot_kpi slides
    KPI_TEXT_*        : Position/size for KPI text boxes
    SUMMARY_*         : Position/size for summary slide bullet grid
    
    Methods
    -------
    build(slides, output_path)
        Create PowerPoint from list of SlideContent objects
    
    Usage
    -----
    builder = DeckBuilder('company_template.pptx')
    builder.build(slides_list, 'output/report.pptx')
    """
    
    # =========================================================================
    # SPACING CONFIGURATION - CSI Template (Template12.25.pptx)
    # =========================================================================
    # These are the DEFAULT values. Layout-specific positioning is handled
    # in _get_positioning() which reads from DECK_CONFIG['positioning'].
    #
    # Standard PowerPoint slide: 10" wide × 7.5" tall
    # =========================================================================
    
    # -------------------------------------------------------------------------
    # Single Screenshot - Default (Layouts 5, 6, 10, 12, 14)
    # Left side, lower on slide
    # -------------------------------------------------------------------------
    SINGLE_IMG_LEFT = Inches(0.5)     # Left side
    SINGLE_IMG_TOP = Inches(2.5)      # Lower on slide
    SINGLE_IMG_WIDTH = Inches(6)      # Smaller width
    
    # -------------------------------------------------------------------------
    # Single Screenshot - Right Side (Layout 11 - Stacked Two)
    # Chart on right two-thirds of slide
    # -------------------------------------------------------------------------
    SINGLE_IMG_RIGHT_LEFT = Inches(5.5)   # Right two-thirds
    SINGLE_IMG_RIGHT_TOP = Inches(2.0)    # Vertically centered
    SINGLE_IMG_RIGHT_WIDTH = Inches(6)    # Two-thirds width
    
    # -------------------------------------------------------------------------
    # Multi-Screenshot - Spaced (Layout 13)
    # Two charts, spread to edges
    # -------------------------------------------------------------------------
    MULTI_IMG_TOP = Inches(2.5)           # Lower on slide
    MULTI_IMG_WIDTH = Inches(4.5)         # Each chart width
    MULTI_IMG_LEFT_POS = Inches(0.5)      # Left chart on left edge
    MULTI_IMG_RIGHT_POS = Inches(7.5)     # Right chart on right edge
    
    # -------------------------------------------------------------------------
    # Multi-Screenshot - Standard (Layout 7)
    # Two charts, closer together
    # -------------------------------------------------------------------------
    MULTI_IMG_STD_TOP = Inches(2.5)
    MULTI_IMG_STD_LEFT_POS = Inches(2.3)
    MULTI_IMG_STD_RIGHT_POS = Inches(7.0)
    MULTI_IMG_STD_WIDTH = Inches(4.5)
    
    # -------------------------------------------------------------------------
    # Screenshot with KPIs (chart left, text right)
    # Used by: _build_screenshot_kpi_slide
    # -------------------------------------------------------------------------
    KPI_IMG_LEFT = Inches(0.3)        # Chart left margin
    KPI_IMG_TOP = Inches(1.5)         # Chart top position
    KPI_IMG_WIDTH = Inches(6)         # Chart width (narrower for KPIs)
    
    KPI_TEXT_LEFT = Inches(6.8)       # KPI text left position
    KPI_TEXT_TOP_START = Inches(1.8)  # First KPI top position
    KPI_TEXT_WIDTH = Inches(2.5)      # KPI text box width
    KPI_VALUE_HEIGHT = Inches(0.5)    # Height for value text box
    KPI_LABEL_HEIGHT = Inches(0.3)    # Height for label text box
    KPI_SPACING = Inches(1.0)         # Vertical space between KPIs
    
    # -------------------------------------------------------------------------
    # Summary Slide (3x3 bullet grid)
    # Used by: _build_summary_slide
    # -------------------------------------------------------------------------
    SUMMARY_COL_POSITIONS = [Inches(0.5), Inches(3.5), Inches(6.5)]
    # X positions for 3 columns
    
    SUMMARY_ROW_START = Inches(1.8)   # First row Y position
    SUMMARY_ROW_SPACING = Inches(1.2) # Vertical space between rows
    SUMMARY_BOX_WIDTH = Inches(2.8)   # Width of each bullet box
    SUMMARY_BOX_HEIGHT = Inches(1.0)  # Height of each bullet box
    
    def __init__(self, template_path: str):
        """
        Initialize DeckBuilder with path to PowerPoint template.
        
        Parameters
        ----------
        template_path : str
            Path to .pptx template file containing your branded layouts.
            Run inspect_template() first to understand available layouts.
        """
        self.template_path = template_path
        self.prs = None  # Presentation object, created in build()
    
    def _get_single_positioning(self, layout_index: int) -> tuple:
        """
        Get positioning for single-chart slides based on layout.
        
        Positions based on CSI template (updated indices).
        
        Returns (left, top, width) in Inches.
        """
        # Layout 4 (Analysis - Slide 1)
        if layout_index == 4:
            return (Inches(0.95), Inches(2.11), Inches(5.5))
        
        # Layout 5 (Analysis - Slide 2)
        if layout_index == 5:
            return (Inches(0.95), Inches(2.11), Inches(5.5))
        
        # Layout 9 (Analysis - Slide 6 - Main)
        if layout_index == 9:
            return (Inches(0.80), Inches(2.12), Inches(6.0))
        
        # Layout 10 (Stacked Two): Chart on right side
        if layout_index == 10:
            return (Inches(5.12), Inches(1.75), Inches(7.0))
        
        # Layout 11 (Analysis - Blank)
        if layout_index == 11:
            return (Inches(2.0), Inches(2.0), Inches(8.0))
        
        # Default fallback
        return (Inches(0.95), Inches(2.11), Inches(5.5))
    
    def _get_multi_positioning(self, layout_index: int) -> tuple:
        """
        Get positioning for multi-chart slides based on layout.
        
        Positions based on CSI template (updated indices).
        
        Returns (top, left_pos, right_pos, width) in Inches.
        """
        # Layout 6 (Analysis - Slide 3 - Split)
        if layout_index == 6:
            return (
                Inches(2.12),
                Inches(0.80),
                Inches(6.78),
                Inches(5.5)
            )
        
        # Layout 7 (Analysis - Slide 4 - Split)
        if layout_index == 7:
            return (
                Inches(2.10),
                Inches(0.80),
                Inches(6.78),
                Inches(5.5)
            )
        
        # Default
        return (
            Inches(2.12),
            Inches(0.80),
            Inches(6.78),
            Inches(5.5)
        )
    
    def build(self, slides: List[SlideContent], output_path: str) -> str:
        """
        Build complete PowerPoint deck from slide definitions.
        
        Iterates through each SlideContent, creates the appropriate slide
        using the template, and saves the result.
        
        Parameters
        ----------
        slides : list of SlideContent
            Ordered list of slides to create. Each SlideContent defines
            one slide's type, title, images, KPIs, etc.
        
        output_path : str
            Where to save the generated .pptx file.
            Parent directories are created if they don't exist.
        
        Returns
        -------
        str
            The output_path (useful for chaining or confirmation).
        
        Example
        -------
        builder = DeckBuilder('template.pptx')
        path = builder.build(slides, 'output/report.pptx')
        print(f"Created: {path}")
        """
        # Open template - this gives us access to all the layouts
        self.prs = Presentation(self.template_path)
        
        # Build each slide
        for slide_content in slides:
            self._add_slide(slide_content)
        
        # Ensure output directory exists
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Save the presentation
        self.prs.save(output_path)
        
        return output_path
    
    def _add_slide(self, content: SlideContent) -> None:
        """
        Create single slide and dispatch to appropriate builder method.
        
        Creates a new slide using the specified layout from the template,
        then calls the correct _build_* method based on slide_type.
        
        Parameters
        ----------
        content : SlideContent
            Definition of the slide to create.
        
        Raises
        ------
        ValueError
            If slide_type is not recognized.
        """
        # Create blank slide from template layout
        slide = self.prs.slides.add_slide(
            self.prs.slide_layouts[content.layout_index]
        )
        
        # Map slide types to builder methods
        builders = {
            'title': self._build_title_slide,
            'section': self._build_section_slide,
            'screenshot': self._build_screenshot_slide,
            'screenshot_kpi': self._build_screenshot_kpi_slide,
            'multi_screenshot': self._build_multi_screenshot_slide,
            'summary': self._build_summary_slide,
        }
        
        # Get the right builder and call it
        builder = builders.get(content.slide_type)
        if builder:
            builder(slide, content)
        else:
            raise ValueError(
                f"Unknown slide_type: '{content.slide_type}'. "
                f"Valid types: {list(builders.keys())}"
            )
    
    # =========================================================================
    # INDIVIDUAL SLIDE BUILDERS
    # =========================================================================
    # Each method below builds a specific type of slide.
    # They all receive a slide object and SlideContent, then populate the slide.
    # =========================================================================
    
    def _build_title_slide(self, slide, content: SlideContent) -> None:
        """
        Build title slide with main title and optional subtitle.
        
        CSI Template cover layouts:
            Layout 0: Cover / Intro - Slide 1 (multiple placeholders)
            Layout 1: Cover / Intro - Slide 2 (single title, custom position needed)
        
        SlideContent Usage:
            - content.title: Main title text (can include \n for line breaks)
            - content.kpis["subtitle"]: Subtitle text (optional)
        """
        # Layout 1 (Cover Style 1): Create custom text box, ignore placeholder
        if content.layout_index == 1:
            # Parse title lines
            title_lines = content.title.split('\n') if '\n' in content.title else [content.title]
            
            # Get subtitle from kpis if provided
            subtitle = content.kpis.get("subtitle", "") if content.kpis else ""
            
            # Build full text: Client Name, line, Month Year
            full_text = title_lines[0]  # Client name
            if len(title_lines) > 1:
                full_text += f"\n{title_lines[1]}"  # Separator line
            if len(title_lines) > 2:
                full_text += f"\n{title_lines[2]}"  # Date
            elif subtitle:
                full_text += f"\n{'─' * 20}\n{subtitle}"  # Add line and subtitle
            
            # Create text box: 1" from left, vertically centered (3.25" from top for 7.5" slide)
            from pptx.util import Inches, Pt
            from pptx.enum.text import PP_ALIGN
            
            text_box = slide.shapes.add_textbox(
                Inches(1.0),      # 1 inch from left
                Inches(3.0),      # Vertically centered
                Inches(6.0),      # Width
                Inches(2.0)       # Height
            )
            
            tf = text_box.text_frame
            tf.word_wrap = True
            
            # Add paragraphs
            lines = full_text.split('\n')
            for i, line in enumerate(lines):
                if i == 0:
                    p = tf.paragraphs[0]
                else:
                    p = tf.add_paragraph()
                
                p.text = line
                p.alignment = PP_ALIGN.LEFT
                
                # First line (client name) is larger
                if i == 0:
                    p.font.size = Pt(32)
                    p.font.bold = True
                else:
                    p.font.size = Pt(18)
            
            return
        
        # Layout 0 and others: Use placeholders
        title_lines = content.title.split('\n') if '\n' in content.title else [content.title]
        
        # Set main title
        if slide.shapes.title:
            slide.shapes.title.text = title_lines[0]
        
        # Handle additional lines and subtitle
        additional_text = title_lines[1:] if len(title_lines) > 1 else []
        
        # Add subtitle from kpis if provided
        if content.kpis and "subtitle" in content.kpis:
            additional_text.append(content.kpis["subtitle"])
        
        # Try to place additional text in available placeholders
        # Layout 0 placeholders: [26] top=2.12", [29] top=2.57", [30] top=3.70"
        text_placeholders = [26, 29, 30, 27, 28, 31]
        
        for i, text in enumerate(additional_text):
            if i < len(text_placeholders):
                try:
                    ph = slide.placeholders[text_placeholders[i]]
                    ph.text = text
                except (KeyError, IndexError):
                    # Try placeholder 1 as fallback (common subtitle position)
                    try:
                        slide.placeholders[1].text = text
                    except (KeyError, IndexError):
                        pass
    
    def _build_section_slide(self, slide, content: SlideContent) -> None:
        """
        Build section divider slide.
        
        CSI Template divider layouts:
            - Layout 2: Title at top, multiple text areas below
            - Layout 3: Title on right
            - Layout 4: Title at top
        
        SlideContent Usage:
            - content.title: "Section Name" or "Section Name\nSubtitle"
        """
        # Parse title and subtitle
        title_text = content.title
        subtitle_text = None
        
        if '\n' in content.title:
            parts = content.title.split('\n', 1)
            title_text = parts[0]
            subtitle_text = parts[1] if len(parts) > 1 else None
        
        # Set title
        if slide.shapes.title:
            slide.shapes.title.text = title_text
        
        # Try to set subtitle in appropriate placeholder
        if subtitle_text:
            # Layout 2 has placeholder [44] for subtitle at top=1.62"
            # Layout 3 has placeholder [1] for content
            # Layout 4 has placeholder [13] for content
            for ph_idx in [44, 13, 1, 14]:
                try:
                    ph = slide.placeholders[ph_idx]
                    ph.text = subtitle_text
                    break
                except (KeyError, IndexError):
                    continue
    
    def _build_screenshot_slide(self, slide, content: SlideContent) -> None:
        """
        Build slide with title, subtitle, and single image.
        
        Template placeholder structure (CSI Template):
            - [0] Title placeholder
            - [13] Subtitle/Content placeholder (below title, indented)
            - [14] Picture placeholder (chart position)
        
        Title format: "Title\nSubtitle" splits into separate placeholders
        
        SlideContent Usage:
            - content.title: Can be "Title" or "Title\nSubtitle"
            - content.images[0]: Path to image file
            - content.layout_index: Determines positioning
        """
        # Parse title and subtitle
        title_text = content.title
        subtitle_text = None
        
        if '\n' in content.title:
            parts = content.title.split('\n', 1)
            title_text = parts[0]
            subtitle_text = parts[1] if len(parts) > 1 else None
        
        # Set title in placeholder [0]
        if slide.shapes.title:
            slide.shapes.title.text = title_text
        
        # Set subtitle in placeholder [13] if it exists
        if subtitle_text:
            try:
                subtitle_placeholder = slide.placeholders[13]
                subtitle_placeholder.text = subtitle_text
            except (KeyError, IndexError):
                # Fallback: some layouts may not have placeholder 13
                pass
        
        # Get layout-specific positioning for the chart
        left, top, width = self._get_single_positioning(content.layout_index)
        
        # Add image if it exists
        if content.images and Path(content.images[0]).exists():
            slide.shapes.add_picture(
                content.images[0],
                left,
                top,
                width=width
            )
    
    def _build_screenshot_kpi_slide(self, slide, content: SlideContent) -> None:
        """
        Build slide with image and KPI callouts.
        
        Template placeholder structure (CSI Template Layout 5, 6):
            - [0] Title placeholder
            - [13] Subtitle/Content placeholder
            - [14] Picture placeholder
            - KPI pairs on right side:
              Layout 5: [26]/[19] (first KPI), [27]/[28] (second KPI)
              Layout 6: [26]/[19] (single KPI)
        
        SlideContent Usage:
            - content.title: "Title" or "Title\nSubtitle"
            - content.images[0]: Path to image file
            - content.kpis: Dict of KPI label-value pairs
        """
        # Parse title and subtitle
        title_text = content.title
        subtitle_text = None
        
        if '\n' in content.title:
            parts = content.title.split('\n', 1)
            title_text = parts[0]
            subtitle_text = parts[1] if len(parts) > 1 else None
        
        # Set title in placeholder [0]
        if slide.shapes.title:
            slide.shapes.title.text = title_text
        
        # Set subtitle in placeholder [13] if it exists
        if subtitle_text:
            try:
                subtitle_placeholder = slide.placeholders[13]
                subtitle_placeholder.text = subtitle_text
            except (KeyError, IndexError):
                pass
        
        # Get layout-specific positioning for the chart
        left, top, width = self._get_single_positioning(content.layout_index)
        
        # Add image
        if content.images and Path(content.images[0]).exists():
            slide.shapes.add_picture(
                content.images[0],
                left,
                top,
                width=width
            )
        
        # Add KPIs using template placeholders
        # Layout 5 KPI placeholders: [26] label, [19] value, [27] label2, [28] value2
        # Layout 6 KPI placeholders: [26] label, [19] value
        if content.kpis:
            # Define placeholder pairs for KPIs (label_idx, value_idx)
            kpi_placeholder_pairs = [
                (26, 19),  # First KPI
                (27, 28),  # Second KPI
            ]
            
            kpi_items = [(k, v) for k, v in content.kpis.items() if k != "subtitle"]
            
            for i, (label, value) in enumerate(kpi_items):
                if i >= len(kpi_placeholder_pairs):
                    break  # Template only supports 2 KPIs
                
                label_idx, value_idx = kpi_placeholder_pairs[i]
                
                # Set label
                try:
                    slide.placeholders[label_idx].text = label
                except (KeyError, IndexError):
                    pass
                
                # Set value
                try:
                    slide.placeholders[value_idx].text = str(value)
                except (KeyError, IndexError):
                    pass
    
    def _build_multi_screenshot_slide(self, slide, content: SlideContent) -> None:
        """
        Build slide with two images side by side.
        
        Template placeholder structure (CSI Template):
            Layout 7: [14] left=0.80" and [1] left=6.78"
            Layout 13: [15] left=0.80" and [1] left=6.78"
        
        SlideContent Usage:
            - content.title: "Title" or "Title\nSubtitle"
            - content.images[0]: Left image path
            - content.images[1]: Right image path
        """
        # Parse title and subtitle
        title_text = content.title
        subtitle_text = None
        
        if '\n' in content.title:
            parts = content.title.split('\n', 1)
            title_text = parts[0]
            subtitle_text = parts[1] if len(parts) > 1 else None
        
        # Set title
        if slide.shapes.title:
            slide.shapes.title.text = title_text
        
        # Set subtitle if exists
        if subtitle_text:
            try:
                subtitle_placeholder = slide.placeholders[13]
                subtitle_placeholder.text = subtitle_text
            except (KeyError, IndexError):
                pass
        
        # Get layout-specific positioning
        top, left_pos, right_pos, width = self._get_multi_positioning(content.layout_index)
        
        # Define positions for left and right images
        positions = [
            (left_pos, top, width),
            (right_pos, top, width),
        ]
        
        # Add each image if it exists
        if content.images:
            for i, img_path in enumerate(content.images[:2]):
                if Path(img_path).exists():
                    left, img_top, img_width = positions[i]
                    slide.shapes.add_picture(img_path, left, img_top, width=img_width)
    
    def _build_summary_slide(self, slide, content: SlideContent) -> None:
        """
        Build summary slide with bullets in 3x3 grid.
        
        Useful for conclusions, recommendations, key takeaways organized
        by category (e.g., Campaign / DCTR / Reg E).
        
        Layout Requirements:
            - Title placeholder
            - Open area for text box grid
        
        SlideContent Usage:
            - content.title: Slide title
            - content.bullets: List of up to 9 strings
        
        Bullet Layout:
            Row 1: bullets[0]  bullets[1]  bullets[2]
            Row 2: bullets[3]  bullets[4]  bullets[5]
            Row 3: bullets[6]  bullets[7]  bullets[8]
        
        Positioning (class constants):
            - 3 columns at 0.5", 3.5", 6.5" from left
            - 3 rows starting at 1.8", spaced 1.2" apart
            - Each box: 2.8" wide × 1.0" tall, word-wrapped
        
        Example:
            SlideContent('summary', 'Key Takeaways',
                        bullets=[
                            "Campaign point 1", "DCTR point 1", "Reg E point 1",
                            "Campaign point 2", "DCTR point 2", "Reg E point 2",
                            "Campaign point 3", "DCTR point 3", "Reg E point 3",
                        ])
        """
        # Set title
        if slide.shapes.title:
            slide.shapes.title.text = content.title
        
        # Add bullets in 3x3 grid
        if content.bullets:
            for i, bullet in enumerate(content.bullets[:9]):  # Max 9 bullets
                # Calculate grid position
                col = i % 3  # 0, 1, 2, 0, 1, 2, ...
                row = i // 3  # 0, 0, 0, 1, 1, 1, 2, 2, 2
                
                # Get x, y position
                left = self.SUMMARY_COL_POSITIONS[col]
                top = self.SUMMARY_ROW_START + (row * self.SUMMARY_ROW_SPACING)
                
                # Create text box
                txbox = slide.shapes.add_textbox(
                    left, top,
                    self.SUMMARY_BOX_WIDTH,
                    self.SUMMARY_BOX_HEIGHT
                )
                
                # Configure text
                tf = txbox.text_frame
                tf.word_wrap = True  # Wrap long text
                tf.paragraphs[0].text = bullet
                tf.paragraphs[0].font.size = Pt(14)


# =============================================================================
# FIGURE CREATION HELPER
# =============================================================================

def make_figure(fig_type: str = 'single') -> Tuple[plt.Figure, plt.Axes]:
    """
    Create matplotlib figure with standardized sizing.
    
    Ensures all charts have consistent dimensions across the deck.
    Sizes are pulled from DECK_CONFIG and can be customized.
    
    Parameters
    ----------
    fig_type : str, default 'single'
        Type of figure to create. Options:
            'single' - Full-width chart (10×6")
            'double' - Side-by-side chart (6×4")
            'kpi'    - Chart with KPIs (8×6")
            'wide'   - Extra wide (12×5")
            'square' - Square aspect (7×7")
    
    Returns
    -------
    tuple of (Figure, Axes)
        Matplotlib figure and axes objects, ready for plotting.
    
    Examples
    --------
    # Standard chart
    fig, ax = make_figure('single')
    df.plot(ax=ax)
    
    # Two charts for side-by-side slide
    fig1, ax1 = make_figure('double')
    fig2, ax2 = make_figure('double')
    
    # Chart that will have KPIs next to it
    fig, ax = make_figure('kpi')
    """
    # Map fig_type to config keys
    size_map = {
        'single': 'fig_single',
        'double': 'fig_double',
        'kpi': 'fig_with_kpi',
        'wide': 'fig_wide',
        'square': 'fig_square',
    }
    
    # Get size from config, default to single
    config_key = size_map.get(fig_type, 'fig_single')
    figsize = DECK_CONFIG.get(config_key, (10, 6))
    
    # Create and return figure
    return plt.subplots(figsize=figsize)


# =============================================================================
# MATPLOTLIB DEFAULTS
# =============================================================================

def apply_matplotlib_defaults() -> None:
    """
    Apply consistent matplotlib styling to all charts.
    
    Call this once in your notebook setup to ensure all charts
    have the same fonts, colors, and appearance.
    
    Settings Applied:
        - Font sizes for titles, labels, ticks, legends
        - Clean look: no top/right spines, no grid
        - White background
    
    Override for Individual Charts:
        After calling make_figure(), you can still customize:
        
        fig, ax = make_figure('single')
        ax.grid(True)  # Turn grid on
        ax.spines['right'].set_visible(True)  # Show spine
    
    Example
    -------
    # In notebook setup cell
    apply_matplotlib_defaults()
    
    # All subsequent charts will use these settings
    fig, ax = make_figure('single')
    df.plot(ax=ax)  # Consistent styling
    """
    plt.rcParams.update({
        # ---------------------------------------------------------------------
        # Font Sizes
        # Tuned for readability when charts are placed on slides
        # ---------------------------------------------------------------------
        'font.size': 12,           # Base font size
        'axes.titlesize': 14,      # Chart title (ax.set_title)
        'axes.labelsize': 12,      # Axis labels (ax.set_xlabel/ylabel)
        'xtick.labelsize': 10,     # X-axis tick labels
        'ytick.labelsize': 10,     # Y-axis tick labels
        'legend.fontsize': 10,     # Legend text
        'figure.titlesize': 16,    # Figure suptitle (rarely used)
        
        # ---------------------------------------------------------------------
        # Visual Style
        # Clean, professional look that works well in presentations
        # ---------------------------------------------------------------------
        'axes.spines.top': False,      # Hide top border
        'axes.spines.right': False,    # Hide right border
        'axes.grid': False,            # No grid lines by default
        
        # ---------------------------------------------------------------------
        # Colors
        # White background ensures charts look good on any slide
        # ---------------------------------------------------------------------
        'figure.facecolor': 'white',   # Figure background
        'axes.facecolor': 'white',     # Plot area background
        'savefig.facecolor': 'white',  # Saved image background
        
        # ---------------------------------------------------------------------
        # Export Settings
        # Tight bounding box removes excess whitespace
        # ---------------------------------------------------------------------
        'savefig.bbox': 'tight',
    })


# =============================================================================
# JUPYTER NOTEBOOK HELPER SETUP
# =============================================================================

def setup_slide_helpers(
    chart_dir: Path,
    deck_config: dict = None
) -> Tuple[list, Callable, Callable, Callable]:
    """
    Initialize slide list and helper functions for Jupyter notebook.
    
    Call this in your notebook setup cells. Returns everything you need
    to build slides as you work through your analysis.
    
    Parameters
    ----------
    chart_dir : Path or str
        Directory where chart images will be saved.
        Created automatically if it doesn't exist.
    
    deck_config : dict, optional
        Configuration dictionary. If None, uses global DECK_CONFIG.
        Pass your customized config if you've modified settings.
    
    Returns
    -------
    tuple of (slides, add_chart_slide, add_section, add_multi_chart_slide)
        slides : list
            Empty list that collects SlideContent objects.
            Pass this to DeckBuilder.build() at the end.
        
        add_chart_slide : function
            Saves figure and adds screenshot/screenshot_kpi slide.
        
        add_section : function
            Adds section divider slide.
        
        add_multi_chart_slide : function
            Saves two figures and adds side-by-side slide.
    
    Example
    -------
    # Setup cell
    chart_dir = Path('./output/charts')
    slides, add_chart_slide, add_section, add_multi_chart_slide = setup_slide_helpers(chart_dir)
    
    # Analysis cell
    fig, ax = make_figure('single')
    df.plot(ax=ax)
    add_chart_slide(fig, 'revenue.png', 'Revenue Trend')
    
    # Final cell
    builder = DeckBuilder('template.pptx')
    builder.build(slides, 'report.pptx')
    """
    # Use provided config or global default
    config = deck_config or DECK_CONFIG
    
    # Ensure chart directory exists
    chart_dir = Path(chart_dir)
    chart_dir.mkdir(parents=True, exist_ok=True)
    
    # Initialize empty slide list
    slides = []
    
    # Create layout cycler from config
    # This iterates through layout indices for visual variety
    chart_layouts = config.get('layout_chart', [5])
    if not isinstance(chart_layouts, list):
        chart_layouts = [chart_layouts]
    layout_cycler = cycle(chart_layouts)
    
    # Get export settings from config
    dpi = config.get('dpi', 150)
    facecolor = config.get('fig_facecolor', 'white')
    
    # -------------------------------------------------------------------------
    # Helper: add_chart_slide
    # -------------------------------------------------------------------------
    def add_chart_slide(
        fig,
        filename: str,
        title: str,
        slide_type: str = 'screenshot',
        kpis: dict = None,
        layout_index: int = None
    ) -> None:
        """
        Save matplotlib figure and add slide to list.
        
        Saves the figure as a PNG, closes it to free memory,
        and creates a SlideContent for the deck.
        
        Parameters
        ----------
        fig : matplotlib.figure.Figure
            Figure to save. Will be closed after saving.
        
        filename : str
            Name for saved image file (e.g., 'dctr_branch.png').
            Saved to chart_dir specified in setup_slide_helpers().
        
        title : str
            Slide title text.
        
        slide_type : str, default 'screenshot'
            Either 'screenshot' (full-width image) or
            'screenshot_kpi' (image with KPI callouts).
        
        kpis : dict, optional
            For slide_type='screenshot_kpi', dict of KPI label-value pairs.
            Example: {"Total": "$1.2M", "Growth": "+5%"}
        
        layout_index : int, optional
            Template layout index. If None, cycles through layouts
            defined in DECK_CONFIG['layout_chart'].
        
        Example
        -------
        fig, ax = make_figure('single')
        df.plot(ax=ax)
        add_chart_slide(fig, 'revenue.png', 'Revenue Trend')
        
        # With KPIs
        add_chart_slide(fig, 'dctr.png', 'DCTR Analysis',
                       slide_type='screenshot_kpi',
                       kpis={"Opportunity": "$50K"})
        """
        # Save figure to chart directory
        path = chart_dir / filename
        fig.savefig(path, dpi=dpi, bbox_inches='tight', facecolor=facecolor)
        plt.close(fig)  # Free memory
        
        # Use provided layout or get next from cycle
        actual_layout = layout_index if layout_index is not None else next(layout_cycler)
        
        # Add to slides list
        slides.append(SlideContent(
            slide_type=slide_type,
            title=title,
            images=[str(path)],
            kpis=kpis,
            layout_index=actual_layout
        ))
    
    # -------------------------------------------------------------------------
    # Helper: add_section
    # -------------------------------------------------------------------------
    def add_section(title: str, layout_index: int = None) -> None:
        """
        Add section divider slide.
        
        Parameters
        ----------
        title : str
            Section title text (displayed large and centered).
        
        layout_index : int, optional
            Template layout index. Defaults to DECK_CONFIG['layout_section'].
        
        Example
        -------
        add_section('Debit Card Take Rate')
        add_section('Reg E Analysis')
        """
        actual_layout = layout_index if layout_index is not None else config.get('layout_section', 2)
        slides.append(SlideContent('section', title, layout_index=actual_layout))
    
    # -------------------------------------------------------------------------
    # Helper: add_multi_chart_slide
    # -------------------------------------------------------------------------
    def add_multi_chart_slide(
        fig1,
        fig2,
        filename1: str,
        filename2: str,
        title: str,
        layout_index: int = None
    ) -> None:
        """
        Save two figures and add as side-by-side slide.
        
        Parameters
        ----------
        fig1, fig2 : matplotlib.figure.Figure
            Figures to save (left and right). Both will be closed.
        
        filename1, filename2 : str
            Names for saved image files.
        
        title : str
            Slide title text.
        
        layout_index : int, optional
            Template layout index. If None, cycles through layouts.
        
        Example
        -------
        fig1, ax1 = make_figure('double')
        fig2, ax2 = make_figure('double')
        
        df_count.plot(ax=ax1)
        df_value.plot(ax=ax2)
        
        add_multi_chart_slide(fig1, fig2,
                             'count.png', 'value.png',
                             'Swipe Performance')
        """
        # Save both figures
        path1 = chart_dir / filename1
        path2 = chart_dir / filename2
        
        fig1.savefig(path1, dpi=dpi, bbox_inches='tight', facecolor=facecolor)
        fig2.savefig(path2, dpi=dpi, bbox_inches='tight', facecolor=facecolor)
        
        plt.close(fig1)
        plt.close(fig2)
        
        # Use provided layout or get next from cycle
        actual_layout = layout_index if layout_index is not None else next(layout_cycler)
        
        # Add to slides list
        slides.append(SlideContent(
            slide_type='multi_screenshot',
            title=title,
            images=[str(path1), str(path2)],
            layout_index=actual_layout
        ))
    
    # Return all helpers
    return slides, add_chart_slide, add_section, add_multi_chart_slide


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def inspect_template(template_path: str) -> None:
    """
    Print all available slide layouts in a PowerPoint template.
    
    Run this once to find the correct layout_index values for your template.
    Note the indices for: title slides, section headers, blank/content layouts.
    
    Parameters
    ----------
    template_path : str
        Path to your .pptx template file.
    
    Example
    -------
    >>> inspect_template('company_template.pptx')
    
    Layouts in company_template.pptx:
    
      0: Title Slide
      1: Title and Content
      2: Section Header
      3: Two Content
      4: Comparison
      5: Blank
      6: Content with Caption
      7: Picture with Caption
    """
    prs = Presentation(template_path)
    print(f"Layouts in {template_path}:\n")
    for i, layout in enumerate(prs.slide_layouts):
        print(f"  {i}: {layout.name}")


def create_title_slide(
    client_name: str,
    period: str,
    layout_index: int = None
) -> SlideContent:
    """
    Convenience function to create a title slide.
    
    Parameters
    ----------
    client_name : str
        Client name for main title.
    
    period : str
        Reporting period for subtitle (e.g., "January 2025").
    
    layout_index : int, optional
        Template layout. Defaults to DECK_CONFIG['layout_title'].
    
    Returns
    -------
    SlideContent
        Configured title slide ready to add to slides list.
    
    Example
    -------
    slides.insert(0, create_title_slide("ABC Credit Union", "January 2025"))
    """
    actual_layout = layout_index if layout_index is not None else DECK_CONFIG.get('layout_title', 1)
    return SlideContent(
        slide_type='title',
        title=f'{client_name} Monthly Report',
        kpis={"subtitle": period},
        layout_index=actual_layout
    )


def create_summary_slide(
    title: str,
    col1_bullets: List[str],
    col2_bullets: List[str],
    col3_bullets: List[str],
    layout_index: int = None
) -> SlideContent:
    """
    Convenience function to create 3-column summary slide.
    
    Organizes bullets by column (e.g., Campaign / DCTR / Reg E),
    then interleaves them for the 3x3 grid layout.
    
    Parameters
    ----------
    title : str
        Slide title.
    
    col1_bullets : list of str
        3 bullets for first column.
    
    col2_bullets : list of str
        3 bullets for second column.
    
    col3_bullets : list of str
        3 bullets for third column.
    
    layout_index : int, optional
        Template layout index.
    
    Returns
    -------
    SlideContent
        Configured summary slide.
    
    Example
    -------
    slides.append(create_summary_slide(
        "Summary & Recommendations",
        col1_bullets=["Campaign 1", "Campaign 2", "Campaign 3"],
        col2_bullets=["DCTR 1", "DCTR 2", "DCTR 3"],
        col3_bullets=["Reg E 1", "Reg E 2", "Reg E 3"]
    ))
    """
    # Interleave bullets for row-by-row display
    # [col1[0], col2[0], col3[0], col1[1], col2[1], col3[1], ...]
    bullets = []
    for i in range(3):
        bullets.append(col1_bullets[i] if i < len(col1_bullets) else "")
        bullets.append(col2_bullets[i] if i < len(col2_bullets) else "")
        bullets.append(col3_bullets[i] if i < len(col3_bullets) else "")
    
    # Determine layout
    actual_layout = layout_index
    if actual_layout is None:
        chart_layouts = DECK_CONFIG.get('layout_chart', [5])
        actual_layout = chart_layouts[0] if isinstance(chart_layouts, list) else chart_layouts
    
    return SlideContent(
        slide_type='summary',
        title=title,
        bullets=bullets,
        layout_index=actual_layout
    )


# =============================================================================
# MODULE TEST / EXAMPLE
# =============================================================================

if __name__ == "__main__":
    # When run directly, show usage example
    print("deck_builder.py - PowerPoint Automation Module")
    print("=" * 50)
    print()
    print("Usage:")
    print("  from deck_builder import (")
    print("      SlideContent, DeckBuilder, setup_slide_helpers,")
    print("      make_figure, apply_matplotlib_defaults, DECK_CONFIG")
    print("  )")
    print()
    print("Quick Start:")
    print("  1. Run: inspect_template('your_template.pptx')")
    print("  2. Update DECK_CONFIG['layout_chart'] with valid indices")
    print("  3. Call setup_slide_helpers(chart_dir)")
    print("  4. Use add_chart_slide() after each analysis")
    print("  5. Call builder.build(slides, 'output.pptx')")
    print()
    print("See README.md for full documentation.")
