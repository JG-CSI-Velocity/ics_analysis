"""
ICS Analysis - Excel Export

Exports analysis results to formatted Excel workbook.
"""

import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle


# =============================================================================
# STYLES
# =============================================================================

HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
HEADER_FONT = Font(bold=True, color="FFFFFF")
THIN_BORDER = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)


# =============================================================================
# EXPORT FUNCTION
# =============================================================================

def export_to_excel(
    results: Dict[str, pd.DataFrame],
    output_path: str,
    summary: dict = None
) -> None:
    """
    Export all results to Excel workbook.
    
    Args:
        results: Dict of {analysis_id: DataFrame}
        output_path: Where to save
        summary: Optional executive summary dict
    """
    wb = Workbook()
    
    # Summary sheet
    ws = wb.active
    ws.title = "Summary"
    _write_summary_sheet(ws, results, summary)
    
    # Each analysis gets its own sheet
    for analysis_id, df in sorted(results.items()):
        if not isinstance(df, pd.DataFrame):
            continue
        
        sheet_name = analysis_id[:31]  # Excel 31 char limit
        new_ws = wb.create_sheet(title=sheet_name)
        _write_data_sheet(new_ws, df, analysis_id)
    
    # Save
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)


def _write_summary_sheet(ws, results: dict, summary: dict = None):
    """Write the summary sheet."""
    ws['A1'] = "ICS Analysis Results"
    ws['A1'].font = Font(bold=True, size=14)
    
    ws['A3'] = "Generated:"
    ws['B3'] = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    # Executive summary if provided
    if summary:
        ws['A5'] = "Executive Summary"
        ws['A5'].font = Font(bold=True, size=12)
        
        row = 6
        for key, value in summary.items():
            ws[f'A{row}'] = key.replace('_', ' ').title()
            if isinstance(value, float) and 0 <= value <= 1:
                ws[f'B{row}'] = f"{value:.1%}"
            elif isinstance(value, float):
                ws[f'B{row}'] = f"${value:,.2f}"
            elif isinstance(value, int):
                ws[f'B{row}'] = f"{value:,}"
            else:
                ws[f'B{row}'] = str(value)
            row += 1
        
        row += 1
    else:
        row = 5
    
    # Analysis index
    ws[f'A{row}'] = "Analyses"
    ws[f'A{row}'].font = Font(bold=True, size=12)
    row += 1
    
    ws[f'A{row}'] = "ID"
    ws[f'B{row}'] = "Rows"
    ws[f'A{row}'].font = Font(bold=True)
    ws[f'B{row}'].font = Font(bold=True)
    row += 1
    
    for analysis_id, df in sorted(results.items()):
        if isinstance(df, pd.DataFrame):
            ws[f'A{row}'] = analysis_id
            ws[f'B{row}'] = len(df)
            row += 1
    
    # Auto-width
    ws.column_dimensions['A'].width = 25
    ws.column_dimensions['B'].width = 15


def _write_data_sheet(ws, df: pd.DataFrame, title: str):
    """Write a data sheet with formatting."""
    # Write data
    for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=True)):
        for c_idx, value in enumerate(row, 1):
            cell = ws.cell(row=r_idx + 1, column=c_idx)
            
            # Handle various types
            if pd.isna(value):
                cell.value = ""
            elif isinstance(value, (int, float)):
                cell.value = value
            else:
                cell.value = str(value)
            
            cell.border = THIN_BORDER
            
            # Header row styling
            if r_idx == 0:
                cell.fill = HEADER_FILL
                cell.font = HEADER_FONT
                cell.alignment = Alignment(horizontal='center')
    
    # Auto-width columns
    for column in ws.columns:
        max_length = 0
        col_letter = column[0].column_letter
        
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        
        ws.column_dimensions[col_letter].width = min(max_length + 2, 40)
    
    # Freeze header row
    ws.freeze_panes = 'A2'
