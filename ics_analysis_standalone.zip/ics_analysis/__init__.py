"""
ICS Analysis Package

Standalone ICS account analysis for credit unions.

Quick Start:
    from ics_analysis import run_client
    results = run_client("1615", ics_not_in_dump=80)

Adding New Analysis:
    1. Copy analyses/_template.py to analyses/ax##_name.py
    2. Update ANALYSIS_ID and ANALYSIS_NAME
    3. Write your run() function
    4. Done - auto-discovered on next run
"""

from .runner import (
    run_client,
    list_clients,
    list_analyses,
    AnalysisRunner,
)

from .config import (
    ICS_CLIENTS,
    generate_last_12_months,
    get_source_file,
)

from .utils import (
    get_ics_accounts,
    get_ics_stat_o,
    get_ics_stat_o_debit,
    add_l12m_activity,
    add_balance_tier,
    add_age_range,
)

__version__ = "1.0.0"

__all__ = [
    'run_client',
    'list_clients',
    'list_analyses',
    'AnalysisRunner',
    'ICS_CLIENTS',
    'get_ics_accounts',
    'get_ics_stat_o',
    'get_ics_stat_o_debit',
]
